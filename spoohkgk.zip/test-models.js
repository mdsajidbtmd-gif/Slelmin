const key = process.env.GEMINI_API_KEY;

try {
  const start = Date.now();
  const res = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-3.8-flash:generateContent?key=${key}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      contents: [{ parts: [{ text: 'Respond with valid JSON: {"status": "ready"}' }] }],
      generationConfig: { responseMimeType: 'application/json' }
    })
  });
  const data = await res.json();
  console.log(`HTTP ${res.status} in ${Date.now() - start}ms:`, JSON.stringify(data));
} catch (e) {
  console.error('Fetch error:', e);
}
