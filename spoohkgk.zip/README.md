# Loupe

See the design. Rebuild it exactly. Inspect fine details in website screenshots and extract pixel-accurate design tokens, typography, and component specifications into `design.md`.

## Features
- **Visual Inspection Pipeline**: Upload screenshot files or paste image URLs to extract design systems.
- **Server-Side AI Extraction**: Runs Gemini models securely on Express backend without exposing API keys.
- **Tokens & Typography**: Color palette extraction, font pairings, spacing scales, and layout structures.
- **Markdown Export**: Copy or download complete `design.md` specifications.

## Running Locally
- `npm run dev` starts the Express server with Vite middleware on port 3000.
- `npm run build` generates the production static assets.

