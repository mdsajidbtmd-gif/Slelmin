import { GoogleGenAI } from '@google/genai';

const key = process.env.GEMINI_API_KEY;
const ai = new GoogleGenAI({ apiKey: key });

const sampleBase64 = 'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==';

const models = [
  'gemini-flash-lite-latest',
  'gemini-3.1-flash-lite',
  'gemini-3.5-flash-lite',
  'gemini-3-flash-preview',
];

for (const model of models) {
  try {
    const start = Date.now();
    const res = await ai.models.generateContent({
      model,
      contents: [{
        role: 'user',
        parts: [
          { text: 'Analyze this image and return JSON: {"detected": true, "type": "pixel"}' },
          { inlineData: { mimeType: 'image/png', data: sampleBase64 } }
        ]
      }],
      config: {
        responseMimeType: 'application/json',
      }
    });
    console.log(`SUCCESS [${model}] in ${Date.now() - start}ms:`, res.text);
  } catch (e) {
    console.log(`FAILED [${model}]:`, e.status, e.message?.slice(0, 80));
  }
}
