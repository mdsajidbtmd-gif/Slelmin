/**
 * Community Library Store
 * Document 2, Section 4.8 & 5.6
 */
import { create } from 'zustand';
import { ShareDoc } from '../types';
import { listPublic } from '../storage/remote';
import { LIBRARY_FIRST_PAGE, LIBRARY_PAGE } from '../config';

export interface LibraryFilters {
  industry: string[];
  style: string[];
  sections: string[];
}

interface LibraryState {
  items: (ShareDoc & { id: string })[];
  cursor: number;
  sort: 'new' | 'copied';
  filters: LibraryFilters;
  search: string;
  status: 'idle' | 'loading' | 'error';
  hasMore: boolean;

  // Actions
  loadInitial: () => Promise<void>;
  loadMore: () => Promise<void>;
  setSearch: (search: string) => void;
  setSort: (sort: 'new' | 'copied') => void;
  toggleFilter: (group: 'industry' | 'style' | 'sections', value: string) => void;
  clearFilters: () => void;
}

const initialFilters: LibraryFilters = {
  industry: [],
  style: [],
  sections: [],
};

export const useLibraryStore = create<LibraryState>((set, get) => ({
  items: [],
  cursor: 0,
  sort: 'new',
  filters: { ...initialFilters },
  search: '',
  status: 'idle',
  hasMore: false,

  loadInitial: async () => {
    set({ status: 'loading', cursor: 0 });
    try {
      const res = await listPublic({
        sort: get().sort,
        pageSize: LIBRARY_FIRST_PAGE,
        cursor: 0,
      });
      set({
        items: res.items,
        cursor: res.items.length,
        hasMore: res.hasMore,
        status: 'idle',
      });
    } catch (e) {
      console.error('Failed to load initial library:', e);
      set({ status: 'error' });
    }
  },

  loadMore: async () => {
    const { cursor, items, sort } = get();
    try {
      const res = await listPublic({
        sort,
        pageSize: LIBRARY_PAGE,
        cursor,
      });
      set({
        items: [...items, ...res.items],
        cursor: cursor + res.items.length,
        hasMore: res.hasMore,
      });
    } catch (e) {
      console.error('Failed to load more library items:', e);
    }
  },

  setSearch: (search: string) => {
    set({ search });
  },

  setSort: (sort: 'new' | 'copied') => {
    set({ sort });
    get().loadInitial();
  },

  toggleFilter: (group: 'industry' | 'style' | 'sections', value: string) => {
    const current = get().filters[group];
    const exists = current.includes(value);
    const updated = exists ? current.filter((v) => v !== value) : [...current, value];
    set({
      filters: {
        ...get().filters,
        [group]: updated,
      },
    });
  },

  clearFilters: () => {
    set({
      filters: {
        industry: [],
        style: [],
        sections: [],
      },
      search: '',
    });
  },
}));
