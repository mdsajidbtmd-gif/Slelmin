/**
 * Generation run state management
 * Document 2, Section 5.6
 */
import { create } from 'zustand';
import { StepName, SiteGroup, PipelineEvent } from '../types';
import { AppError } from '../services/errors';
import { runPipeline } from '../services/pipeline';

export type RunPhase =
  | 'idle'
  | 'files_selected'
  | 'checking'
  | 'choosing'
  | 'processing'
  | 'rejected'
  | 'done'
  | 'error';

interface RunState {
  files: File[];
  fileIssues: { fileName: string; code: string; reason?: string }[];
  stepStatus: Record<StepName, 'pending' | 'active' | 'done'>;
  retryInfo: { inSeconds: number; attempt: number } | null;
  sites: SiteGroup[];
  phase: RunPhase;
  error: AppError | null;
  resultIds: string[];
  elapsedSeconds: number;
  abortController: AbortController | null;
  choiceResolver: ((choice: { siteIds: string[] }) => void) | null;

  // Actions
  setFiles: (files: File[]) => void;
  reorderFiles: (fromIndex: number, toIndex: number) => void;
  removeFile: (index: number) => void;
  clearFiles: () => void;
  startRun: () => Promise<void>;
  cancelRun: () => void;
  resolveChoice: (choice: { siteIds: string[] }) => void;
  resetRun: () => void;
  incrementElapsed: () => void;
}

const initialStepStatus: Record<StepName, 'pending' | 'active' | 'done'> = {
  check: 'pending',
  measure: 'pending',
  analyze: 'pending',
  extract: 'pending',
  validate: 'pending',
};

export const useRunStore = create<RunState>((set, get) => ({
  files: [],
  fileIssues: [],
  stepStatus: { ...initialStepStatus },
  retryInfo: null,
  sites: [],
  phase: 'idle',
  error: null,
  resultIds: [],
  elapsedSeconds: 0,
  abortController: null,
  choiceResolver: null,

  setFiles: (newFiles) => {
    set({
      files: newFiles,
      phase: newFiles.length > 0 ? 'files_selected' : 'idle',
      fileIssues: [],
      error: null,
    });
  },

  reorderFiles: (fromIndex, toIndex) => {
    const { files } = get();
    if (fromIndex < 0 || fromIndex >= files.length || toIndex < 0 || toIndex >= files.length) return;
    const updated = [...files];
    const [moved] = updated.splice(fromIndex, 1);
    updated.splice(toIndex, 0, moved);
    set({ files: updated });
  },

  removeFile: (index) => {
    const { files } = get();
    const updated = files.filter((_, i) => i !== index);
    set({
      files: updated,
      phase: updated.length > 0 ? 'files_selected' : 'idle',
    });
  },

  clearFiles: () => {
    set({
      files: [],
      fileIssues: [],
      phase: 'idle',
      error: null,
      resultIds: [],
    });
  },

  incrementElapsed: () => {
    set((state) => ({ elapsedSeconds: state.elapsedSeconds + 1 }));
  },

  cancelRun: () => {
    const { abortController } = get();
    if (abortController) {
      abortController.abort();
    }
    set({
      phase: 'files_selected',
      abortController: null,
      stepStatus: { ...initialStepStatus },
      retryInfo: null,
      choiceResolver: null,
      elapsedSeconds: 0,
    });
  },

  resolveChoice: (choice) => {
    const { choiceResolver } = get();
    if (choiceResolver) {
      choiceResolver(choice);
      set({ choiceResolver: null, phase: 'processing' });
    }
  },

  resetRun: () => {
    set({
      stepStatus: { ...initialStepStatus },
      retryInfo: null,
      phase: get().files.length > 0 ? 'files_selected' : 'idle',
      error: null,
      resultIds: [],
      elapsedSeconds: 0,
      abortController: null,
      choiceResolver: null,
    });
  },

  startRun: async () => {
    const { files, phase } = get();
    if (files.length === 0 || phase === 'processing') return;

    const controller = new AbortController();
    set({
      phase: 'processing',
      stepStatus: { ...initialStepStatus },
      retryInfo: null,
      error: null,
      resultIds: [],
      elapsedSeconds: 0,
      abortController: controller,
      fileIssues: [],
    });

    const handleEvent = (event: PipelineEvent) => {
      switch (event.type) {
        case 'step': {
          set((state) => ({
            stepStatus: {
              ...state.stepStatus,
              [event.step]: event.status,
            },
          }));
          break;
        }
        case 'retry': {
          set({ retryInfo: { inSeconds: event.inSeconds, attempt: event.attempt } });
          break;
        }
        case 'rejected': {
          set({
            phase: 'rejected',
            fileIssues: event.items,
            abortController: null,
          });
          break;
        }
        case 'cache_hit': {
          set({ resultIds: [event.resultId] });
          break;
        }
        case 'done': {
          set({
            phase: 'done',
            resultIds: event.resultIds,
            abortController: null,
          });
          break;
        }
        case 'error': {
          const isCancelled = 'code' in event.error && event.error.code === 'cancelled';
          if (isCancelled) {
            set({
              phase: 'files_selected',
              abortController: null,
            });
          } else {
            set({
              phase: 'error',
              error: event.error instanceof AppError ? event.error : new AppError('network', event.error.message),
              abortController: null,
            });
          }
          break;
        }
      }
    };

    const requestChoice = (detectedSites: SiteGroup[]): Promise<{ siteIds: string[] }> => {
      return new Promise<{ siteIds: string[] }>((resolve) => {
        set({
          sites: detectedSites,
          phase: 'choosing',
          choiceResolver: resolve,
        });
      });
    };

    await runPipeline(files, {
      signal: controller.signal,
      onEvent: handleEvent,
      requestChoice,
    });
  },
}));
