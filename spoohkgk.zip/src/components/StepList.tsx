/**
 * Five-step processing progress list
 * Document 2, Section 4.4
 */
import React, { useEffect, useState } from 'react';
import { Check, Loader2 } from 'lucide-react';
import { StepName } from '../types';

interface StepListProps {
  stepStatus: Record<StepName, 'pending' | 'active' | 'done'>;
  elapsedSeconds: number;
  retryInfo: { inSeconds: number; attempt: number } | null;
  onCancel: () => void;
}

export const StepList: React.FC<StepListProps> = ({
  stepStatus,
  elapsedSeconds,
  retryInfo,
  onCancel,
}) => {
  const [retryCountdown, setRetryCountdown] = useState<number | null>(null);

  useEffect(() => {
    if (!retryInfo) {
      setRetryCountdown(null);
      return;
    }
    setRetryCountdown(retryInfo.inSeconds);
    const interval = setInterval(() => {
      setRetryCountdown((prev) => {
        if (prev === null || prev <= 1) return null;
        return prev - 1;
      });
    }, 1000);
    return () => clearInterval(interval);
  }, [retryInfo]);

  const steps: { key: StepName; label: string; testId: string }[] = [
    {
      key: 'check',
      label: 'Checking and preparing images',
      testId: 'step-check',
    },
    {
      key: 'measure',
      label: 'Measuring palette and layout geometry',
      testId: 'step-measure',
    },
    {
      key: 'analyze',
      label: 'Analyzing design structure and sections',
      testId: 'step-analyze',
    },
    {
      key: 'extract',
      label: 'Extracting tokens, components, and layout',
      testId: 'step-extract',
    },
    {
      key: 'validate',
      label: 'Validating specifications and rendering design.md',
      testId: 'step-validate',
    },
  ];

  const formatElapsed = (sec: number) => {
    const m = Math.floor(sec / 60);
    const s = sec % 60;
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  return (
    <div className="w-full max-w-lg mx-auto bg-[#0d0d0d] rounded-[16px] p-8 inset-border flex flex-col gap-6">
      <div className="flex flex-col gap-1 text-left">
        <h2 className="text-xl font-medium text-white tracking-[-0.027em]">
          Inspecting Design Details
        </h2>
        <p className="text-sm text-[#858585]">
          Analyzing screenshots and building the design system specification.
        </p>
      </div>

      {/* Step items */}
      <div className="flex flex-col gap-4">
        {steps.map((s) => {
          const status = stepStatus[s.key];
          return (
            <div
              key={s.key}
              data-testid={s.testId}
              className="flex items-center gap-3 text-left"
            >
              <div className="w-6 h-6 rounded-full flex items-center justify-center shrink-0">
                {status === 'done' && (
                  <div className="w-5 h-5 rounded-full bg-[#1f1f1f] text-white flex items-center justify-center inset-border">
                    <Check className="w-3 h-3 text-white" />
                  </div>
                )}
                {status === 'active' && (
                  <Loader2 className="w-4 h-4 text-[#0063e1] animate-spin" />
                )}
                {status === 'pending' && (
                  <div className="w-2 h-2 rounded-full bg-[#858585]/40" />
                )}
              </div>
              <span
                className={`text-sm ${
                  status === 'active'
                    ? 'text-white font-medium'
                    : status === 'done'
                    ? 'text-white'
                    : 'text-[#858585]'
                }`}
              >
                {s.label}
              </span>
            </div>
          );
        })}
      </div>

      {/* Live elapsed & retry status */}
      <div className="flex flex-col gap-1 border-t border-[rgba(255,255,255,0.08)] pt-4 text-xs text-[#858585] font-mono text-left">
        <div className="flex justify-between items-center">
          <span>Elapsed time: {formatElapsed(elapsedSeconds)}</span>
          <button
            type="button"
            data-testid="btn-cancel"
            onClick={onCancel}
            className="text-xs text-[#858585] hover:text-white font-sans underline cursor-pointer"
          >
            Cancel
          </button>
        </div>

        {elapsedSeconds > 20 && (
          <p className="text-[#858585] font-sans text-xs mt-1">
            Still working. The free testing quota can be slow.
          </p>
        )}

        {retryCountdown !== null && retryCountdown > 0 && (
          <p className="text-white font-sans text-xs mt-1">
            The service is busy. Retrying in {retryCountdown} s.
          </p>
        )}
      </div>
    </div>
  );
};
