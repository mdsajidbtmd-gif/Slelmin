/**
 * Library Card component
 * Document 2, Section 4.8
 */
import React from 'react';
import { Link } from 'react-router-dom';
import { Copy } from 'lucide-react';
import { ShareDoc } from '../types';

interface LibraryCardProps {
  item: ShareDoc & { id: string };
}

export const LibraryCard: React.FC<LibraryCardProps> = ({ item }) => {
  const allTags = [
    ...(item.tags.industry || []),
    ...(item.tags.style || []),
    ...(item.tags.sections || []),
  ].slice(0, 3);

  const formattedDate = item.createdAt
    ? new Date(typeof item.createdAt === 'number' ? item.createdAt : Date.now()).toLocaleDateString('en-US', {
        month: 'short',
        day: 'numeric',
      })
    : '';

  return (
    <Link
      to={`/s/${item.id}`}
      data-testid={`library-card-${item.id}`}
      className="bg-[#0d0d0d] hover:bg-[#1f1f1f] rounded-[16px] inset-border p-4 flex flex-col gap-3 transition-all group text-left cursor-pointer"
    >
      {/* Cover Image Container */}
      <div className="w-full h-44 rounded-[12px] bg-[#040910] overflow-hidden inset-border flex items-center justify-center relative">
        {item.coverImage ? (
          <img
            src={item.coverImage}
            alt={item.title}
            className="w-full h-full object-cover group-hover:scale-102 transition-transform duration-300"
          />
        ) : (
          <div className="text-xs text-[#858585] font-mono">No preview</div>
        )}
      </div>

      {/* Title */}
      <h3 className="text-sm font-medium text-white line-clamp-1 tracking-[-0.01em] group-hover:text-white">
        {item.title}
      </h3>

      {/* Tags and Meta */}
      <div className="flex items-center justify-between mt-auto pt-2 border-t border-[rgba(255,255,255,0.06)] text-xs text-[#858585]">
        <div className="flex flex-wrap gap-1">
          {allTags.map((tag) => (
            <span
              key={tag}
              className="bg-[#1f1f1f] text-[#858585] text-[11px] font-mono px-2 py-0.5 rounded-[4px]"
            >
              {tag}
            </span>
          ))}
        </div>

        <div className="flex items-center gap-3 shrink-0 ml-2 font-mono text-[11px]">
          <span className="flex items-center gap-1" title="Copies">
            <Copy className="w-3 h-3" />
            {item.copyCount || 0}
          </span>
          {formattedDate && <span>{formattedDate}</span>}
        </div>
      </div>
    </Link>
  );
};
