/**
 * Page Footer
 * Document 2 & DESIGN.md
 */
import React from 'react';
import { Link } from 'react-router-dom';
import { APP_NAME, TAGLINE, PIPELINE_VERSION } from '../config';

export const Footer: React.FC = () => {
  return (
    <footer className="w-full border-t border-[rgba(255,255,255,0.08)] bg-[#000000] mt-20 py-12 transition-colors no-print">
      <div className="max-w-[1200px] mx-auto px-6 flex flex-col md:flex-row items-center justify-between gap-6">
        <div className="flex flex-col items-center md:items-start gap-1">
          <div className="flex items-center gap-2">
            <svg
              className="w-4 h-4 text-[#0063e1]"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2.5"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <circle cx="11" cy="11" r="7" />
              <line x1="16.5" y1="16.5" x2="21" y2="21" />
            </svg>
            <span className="font-semibold text-sm text-white">{APP_NAME}</span>
          </div>
          <p className="text-xs text-[#858585] tracking-[-0.005em]">{TAGLINE}</p>
        </div>

        <div className="flex items-center gap-6 text-xs text-[#858585]">
          <Link to="/generate" className="hover:text-white transition-colors">
            Generate
          </Link>
          <Link to="/library" className="hover:text-white transition-colors">
            Library
          </Link>
          <Link to="/tutorial" className="hover:text-white transition-colors">
            Tutorial
          </Link>
          <Link to="/history" className="hover:text-white transition-colors">
            History
          </Link>
        </div>

        <div className="text-xs text-[#858585] font-mono">
          Pipeline v{PIPELINE_VERSION}
        </div>
      </div>
    </footer>
  );
};
