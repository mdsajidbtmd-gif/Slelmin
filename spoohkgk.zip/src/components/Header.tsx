/**
 * Navigation Header
 * Document 2, Section 4.0 & DESIGN.md
 */
import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { APP_NAME } from '../config';

export const Header: React.FC = () => {
  const location = useLocation();
  const currentPath = location.pathname;

  const navLinks = [
    { label: 'Generate', path: '/generate' },
    { label: 'Library', path: '/library' },
    { label: 'Tutorial', path: '/tutorial' },
    { label: 'History', path: '/history' },
  ];

  return (
    <header className="h-[80px] w-full border-b border-[rgba(255,255,255,0.08)] bg-[#000000]/80 backdrop-blur-md sticky top-0 z-40 transition-colors">
      <div className="max-w-[1200px] h-full mx-auto px-6 flex items-center justify-between">
        {/* Brand Logo & Wordmark */}
        <Link to="/" className="flex items-center gap-2 group cursor-pointer" aria-label="Loupe Home">
          {/* Lens Icon: circle with diagonal handle in Signal Blue #0063e1 */}
          <svg
            className="w-5 h-5 text-[#0063e1] transition-transform group-hover:scale-105"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2.5"
            strokeLinecap="round"
            strokeLinejoin="round"
          >
            <circle cx="11" cy="11" r="7" />
            <line x1="16.5" y1="16.5" x2="21" y2="21" />
          </svg>
          <span className="font-semibold text-xl tracking-tight text-white">{APP_NAME}</span>
        </Link>

        {/* Center Nav Links */}
        <nav className="flex items-center gap-8" aria-label="Main Navigation">
          {navLinks.map((link) => {
            const isActive = currentPath === link.path;
            return (
              <Link
                key={link.path}
                to={link.path}
                className={`text-[15px] font-normal tracking-[-0.007em] transition-colors ${
                  isActive ? 'text-white' : 'text-[#858585] hover:text-[#d1d1d1]'
                }`}
              >
                {link.label}
              </Link>
            );
          })}
        </nav>

        {/* Right Action */}
        <div className="flex items-center gap-4">
          <Link
            to="/generate"
            className="hidden sm:inline-flex items-center justify-center bg-[#0063e1] hover:bg-[#0052be] text-white text-[13px] font-medium tracking-[-0.005em] px-4 py-2 rounded-[59px] transition-colors"
          >
            Generate design.md
          </Link>
        </div>
      </div>
    </header>
  );
};
