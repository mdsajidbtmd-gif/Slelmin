/**
 * Image Lightbox overlay
 * Document 2, Section 4.0 & 4.9
 */
import React, { useEffect } from 'react';
import { X, ChevronLeft, ChevronRight } from 'lucide-react';

interface LightboxProps {
  images: { dataUrl: string; name?: string }[];
  currentIndex: number;
  isOpen: boolean;
  onClose: () => void;
  onPrev: () => void;
  onNext: () => void;
}

export const Lightbox: React.FC<LightboxProps> = ({
  images,
  currentIndex,
  isOpen,
  onClose,
  onPrev,
  onNext,
}) => {
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (!isOpen) return;
      if (e.key === 'Escape') onClose();
      if (e.key === 'ArrowLeft') onPrev();
      if (e.key === 'ArrowRight') onNext();
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose, onPrev, onNext]);

  if (!isOpen || images.length === 0) return null;

  const current = images[currentIndex] || images[0];

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/90 p-4 backdrop-blur-md select-none no-print"
      onClick={onClose}
    >
      <div
        className="relative max-w-5xl max-h-[90vh] flex flex-col items-center"
        onClick={(e) => e.stopPropagation()}
      >
        <img
          src={current.dataUrl}
          alt={current.name || `Image ${currentIndex + 1}`}
          className="max-w-full max-h-[80vh] object-contain rounded-[12px] inset-border shadow-2xl"
        />

        <div className="flex items-center justify-between w-full mt-4 text-xs text-[#858585] font-mono">
          <span>{current.name || `Image ${currentIndex + 1} of ${images.length}`}</span>
          <span>{currentIndex + 1} / {images.length}</span>
        </div>

        {/* Close Button */}
        <button
          type="button"
          onClick={onClose}
          aria-label="Close Lightbox"
          className="absolute -top-12 right-0 p-2 text-[#858585] hover:text-white rounded-full bg-[#1f1f1f] inset-border cursor-pointer"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Prev / Next controls */}
        {images.length > 1 && (
          <>
            <button
              type="button"
              onClick={onPrev}
              aria-label="Previous Image"
              className="absolute left-[-50px] top-1/2 -translate-y-1/2 p-2 text-[#858585] hover:text-white rounded-full bg-[#1f1f1f] inset-border cursor-pointer hidden md:flex items-center justify-center"
            >
              <ChevronLeft className="w-5 h-5" />
            </button>
            <button
              type="button"
              onClick={onNext}
              aria-label="Next Image"
              className="absolute right-[-50px] top-1/2 -translate-y-1/2 p-2 text-[#858585] hover:text-white rounded-full bg-[#1f1f1f] inset-border cursor-pointer hidden md:flex items-center justify-center"
            >
              <ChevronRight className="w-5 h-5" />
            </button>
          </>
        )}
      </div>
    </div>
  );
};
