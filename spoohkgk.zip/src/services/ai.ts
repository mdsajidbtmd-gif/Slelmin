/**
 * Gemini API handling & Multi-Pass Visual Inspection
 * Document 2, Section 5.5 & Visual Reproduction Specification T1, T5, T6, T7
 */
import { GoogleGenAI } from '@google/genai';
import {
  GEMINI_MODEL,
  GEMINI_ANALYZE_MODEL,
  GEMINI_LOCATE_MODEL,
  GEMINI_FALLBACK_MODELS,
  GEN_CONFIG,
  EXTRACT_GEN_CONFIG,
  ANALYZE_PROMPT,
  EXTRACT_PROMPT,
  LOCATE_PROMPT,
  REGION_PROMPT,
  CALL_TIMEOUT_MS,
  RETRY_DELAYS_MS,
  SCHEMA_RETRIES,
} from '../config';
import { AppError, mapError } from './errors';
import { AnalyzeResult, Box2D, DesignSpec, Measurements } from '../types';
import { validateAnalyzeResult, validateDesignSpec } from './validate';

// Lazy initialize SDK on server / Node side
let aiClient: GoogleGenAI | null = null;

export function getAiClient(): GoogleGenAI {
  if (aiClient) return aiClient;
  const key = process.env.GEMINI_API_KEY;
  if (!key) {
    throw new AppError('ai_config', 'GEMINI_API_KEY environment variable is not set.');
  }
  aiClient = new GoogleGenAI({
    apiKey: key,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build-loupe-v2',
      },
    },
  });
  console.log(`[Loupe AI] Configured models: Extract=${GEMINI_MODEL}, Analyze=${GEMINI_ANALYZE_MODEL}, Locate=${GEMINI_LOCATE_MODEL}`);
  return aiClient;
}

function sleep(ms: number, signal?: AbortSignal): Promise<void> {
  return new Promise((resolve, reject) => {
    if (signal?.aborted) return reject(new AppError('cancelled'));
    const timer = setTimeout(resolve, ms);
    signal?.addEventListener(
      'abort',
      () => {
        clearTimeout(timer);
        reject(new AppError('cancelled'));
      },
      { once: true }
    );
  });
}

async function withTimeout<T>(promise: Promise<T>, ms: number, signal?: AbortSignal): Promise<T> {
  let timer: any;
  const timeoutPromise = new Promise<never>((_, reject) => {
    timer = setTimeout(() => reject(new AppError('network', 'Request timed out')), ms);
  });

  try {
    return await Promise.race([promise, timeoutPromise]);
  } finally {
    clearTimeout(timer);
  }
}

export async function withRetry<T>(
  fn: () => Promise<T>,
  signal: AbortSignal,
  onRetry: (seconds: number, attempt: number) => void
): Promise<T> {
  for (let attempt = 0; ; attempt++) {
    try {
      if (signal.aborted) throw new AppError('cancelled');
      return await withTimeout(fn(), CALL_TIMEOUT_MS, signal);
    } catch (err: any) {
      if (signal.aborted || err?.message?.includes('cancelled')) throw new AppError('cancelled');
      const status = err?.status;
      const isTimeout =
        err?.message?.includes('timed out') ||
        err?.message?.includes('timeout') ||
        err?.code === 'network';
      const retryable =
        [429, 500, 503, 504].includes(status) ||
        err instanceof TypeError ||
        err?.code === 'quota' ||
        isTimeout;
      if (!retryable || attempt >= RETRY_DELAYS_MS.length) {
        throw mapError(err);
      }
      const delaySeconds = RETRY_DELAYS_MS[attempt] / 1000;
      onRetry(delaySeconds, attempt + 1);
      await sleep(RETRY_DELAYS_MS[attempt], signal);
    }
  }
}

/**
 * Cleans potential markdown code blocks around JSON
 */
export function cleanJsonResponse(text: string): string {
  let cleaned = text.trim();
  if (cleaned.startsWith('```json')) {
    cleaned = cleaned.replace(/^```json\s*/, '').replace(/\s*```$/, '');
  } else if (cleaned.startsWith('```')) {
    cleaned = cleaned.replace(/^```\s*/, '').replace(/\s*```$/, '');
  }
  return cleaned.trim();
}

/**
 * Executes generateContent with automated fallback to alternative flash models on 503/429/404/timeouts
 * Wrapped with a strict 35-second per-model timeout so an unresponsive model never hangs the whole pipeline.
 */
async function generateContentWithFallback(
  ai: GoogleGenAI,
  primaryModel: string,
  params: {
    contents: any[];
    systemInstruction: string;
    config?: any;
  }
) {
  const models = Array.from(new Set([primaryModel, ...(GEMINI_FALLBACK_MODELS || [])]));
  let lastError: any = null;

  for (const model of models) {
    try {
      const modelPromise = ai.models.generateContent({
        model,
        contents: params.contents,
        config: {
          systemInstruction: params.systemInstruction,
          ...(params.config || GEN_CONFIG),
          responseMimeType: 'application/json',
        },
      });

      // Bound each individual model to max 35s
      const res = await withTimeout(modelPromise, 35000);
      return res;
    } catch (err: any) {
      lastError = err;
      const status = Number(err?.status || err?.statusCode || 0);
      const msg = String(err?.message || '');
      const lower = msg.toLowerCase();
      console.warn(`Model ${model} failed (status ${status}): ${msg.slice(0, 120)}. Trying fallback...`);
      const isNotFound = status === 404 || lower.includes('not found') || lower.includes('not_found');
      const isUnavailable =
        status === 503 ||
        status === 429 ||
        status === 500 ||
        lower.includes('unavailable') ||
        lower.includes('resource_exhausted') ||
        lower.includes('timed out') ||
        lower.includes('timeout') ||
        lower.includes('high demand');
      if (isNotFound || isUnavailable) {
        continue;
      }
      throw err;
    }
  }

  throw lastError;
}

/**
 * Server-side direct execution: Analyze
 */
export async function directAiAnalyze(
  images: { base64: string; mimeType?: string }[],
  signal?: AbortSignal
): Promise<AnalyzeResult> {
  const ai = getAiClient();
  const parts: any[] = [];

  images.forEach((img, idx) => {
    parts.push({ text: `img${idx + 1}` });
    parts.push({
      inlineData: {
        mimeType: img.mimeType || 'image/png',
        data: img.base64,
      },
    });
  });

  const res = await generateContentWithFallback(ai, GEMINI_ANALYZE_MODEL, {
    contents: [{ role: 'user', parts }],
    systemInstruction: ANALYZE_PROMPT,
    config: GEN_CONFIG,
  });

  const candidate = res.candidates?.[0];
  if (candidate?.finishReason === 'SAFETY' || res.promptFeedback?.blockReason) {
    throw new AppError('adult_or_unsafe');
  }

  if (!res.text || !res.text.trim()) {
    throw new AppError('unreadable', 'AI analyze response was empty');
  }

  const raw = cleanJsonResponse(res.text);
  let parsed: any;
  try {
    parsed = JSON.parse(raw);
  } catch (err: any) {
    throw new AppError('unreadable', `Analyze response was not valid JSON: ${err?.message}`);
  }

  // T1: No silent fabrication of fake site sections
  if (parsed.isWebsite && (!parsed.sites || parsed.sites.length === 0)) {
    parsed.sites = [
      {
        id: 'site-1',
        label: 'unknown',
        description: 'unknown',
        sections: [],
        imageIndices: images.map((_, i) => i),
      },
    ];
  }

  const validated = validateAnalyzeResult(parsed);
  if (!validated.success || !validated.data) {
    throw new AppError('unreadable', `Analyze schema error: ${validated.errors?.join(', ')}`);
  }

  return validated.data;
}

/**
 * Server-side direct execution: Extract (Tokens + VisualSpec in one call)
 */
export async function directAiExtract(
  images: { base64: string; mimeType?: string }[],
  measurements: Measurements,
  signal?: AbortSignal
): Promise<DesignSpec> {
  const ai = getAiClient();
  let lastError: any = null;

  for (let retry = 0; retry <= SCHEMA_RETRIES; retry++) {
    try {
      const parts: any[] = [];

      images.forEach((img, idx) => {
        parts.push({ text: `img${idx + 1}` });
        parts.push({
          inlineData: {
            mimeType: img.mimeType || 'image/png',
            data: img.base64,
          },
        });
      });

      // Provide measurements with coordinates and colors
      parts.push({
        text: `MEASURED PALETTE AND PIXEL DATA:\n${JSON.stringify(measurements, null, 2)}`,
      });

      const res = await generateContentWithFallback(ai, GEMINI_MODEL, {
        contents: [{ role: 'user', parts }],
        systemInstruction: EXTRACT_PROMPT,
        config: EXTRACT_GEN_CONFIG,
      });

      const candidate = res.candidates?.[0];
      if (candidate?.finishReason === 'SAFETY' || res.promptFeedback?.blockReason) {
        throw new AppError('adult_or_unsafe');
      }

      if (candidate?.finishReason === 'MAX_TOKENS') {
        throw new AppError('quota', 'Gemini output truncated due to MAX_TOKENS.');
      }

      if (!res.text || !res.text.trim()) {
        throw new AppError('unreadable', 'AI extract response was empty.');
      }

      const raw = cleanJsonResponse(res.text);
      const parsed = JSON.parse(raw);
      const validated = validateDesignSpec(parsed);

      if (!validated.success || !validated.data) {
        throw new Error(`Schema validation error: ${validated.errors?.join(', ')}`);
      }

      // Populate detected crop into VisualSpec if available
      if (validated.data.visualSpec && measurements.cropRect) {
        validated.data.visualSpec.frame.detectedCrop = measurements.cropRect;
      }

      return validated.data;
    } catch (err: any) {
      lastError = err;
      if (retry < SCHEMA_RETRIES) {
        console.warn(`Extraction attempt ${retry + 1} failed: ${err.message}. Retrying...`);
        await sleep(1500, signal);
      }
    }
  }

  throw new AppError('unreadable', `Extraction failed after ${SCHEMA_RETRIES + 1} attempts: ${lastError?.message || lastError}`);
}

/**
 * Pass A: Locate elements using Gemini's native box_2d
 */
export async function directAiLocate(
  images: { base64: string; mimeType?: string }[],
  signal?: AbortSignal
): Promise<{ id: string; kind: string; label: string; box_2d: [number, number, number, number]; text?: string }[]> {
  const ai = getAiClient();
  const parts: any[] = [];

  images.forEach((img, idx) => {
    parts.push({ text: `img${idx + 1}` });
    parts.push({
      inlineData: {
        mimeType: img.mimeType || 'image/png',
        data: img.base64,
      },
    });
  });

  const res = await generateContentWithFallback(ai, GEMINI_LOCATE_MODEL, {
    contents: [{ role: 'user', parts }],
    systemInstruction: LOCATE_PROMPT,
    config: GEN_CONFIG,
  });

  const raw = cleanJsonResponse(res.text || '{}');
  const parsed = JSON.parse(raw);
  return Array.isArray(parsed.elements) ? parsed.elements.slice(0, 60) : [];
}

/**
 * Pass B: High-magnification inspection of an isolated region
 */
export async function directAiZoomRegion(
  regionImageBase64: string,
  regionMeasurements: any,
  signal?: AbortSignal
): Promise<any> {
  const ai = getAiClient();
  const parts = [
    { text: 'ZOOMED_REGION_CROP' },
    { inlineData: { mimeType: 'image/png', data: regionImageBase64 } },
    { text: `MEASURED REGION DATA:\n${JSON.stringify(regionMeasurements, null, 2)}` },
  ];

  const res = await generateContentWithFallback(ai, GEMINI_MODEL, {
    contents: [{ role: 'user', parts }],
    systemInstruction: REGION_PROMPT,
    config: EXTRACT_GEN_CONFIG,
  });

  const raw = cleanJsonResponse(res.text || '{}');
  return JSON.parse(raw);
}

// ----------------------------------------------------------------------------
// Universal Client/Server Callers
// ----------------------------------------------------------------------------

export async function callAiAnalyze(
  images: { base64: string; mimeType?: string }[],
  signal: AbortSignal,
  onRetry: (seconds: number, attempt: number) => void
): Promise<AnalyzeResult> {
  return withRetry(
    async () => {
      if (typeof window !== 'undefined') {
        const resp = await fetch('/api/ai/analyze', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ images }),
          signal,
        });

        if (!resp.ok) {
          const errorJson = await resp.json().catch(() => ({}));
          const err = new AppError(errorJson.code || 'network', errorJson.message || `Server responded with ${resp.status}`);
          (err as any).status = errorJson.status || resp.status;
          throw err;
        }

        const data = await resp.json();
        const validated = validateAnalyzeResult(data);
        if (!validated.success || !validated.data) {
          throw new AppError('unreadable', 'Validation error from analyze endpoint');
        }
        return validated.data;
      } else {
        return directAiAnalyze(images, signal);
      }
    },
    signal,
    onRetry
  );
}

export async function callAiExtract(
  images: { base64: string; mimeType?: string }[],
  measurements: Measurements,
  signal: AbortSignal,
  onRetry: (seconds: number, attempt: number) => void
): Promise<DesignSpec> {
  return withRetry(
    async () => {
      if (typeof window !== 'undefined') {
        const resp = await fetch('/api/ai/extract', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ images, measurements }),
          signal,
        });

        if (!resp.ok) {
          const errorJson = await resp.json().catch(() => ({}));
          const err = new AppError(errorJson.code || 'network', errorJson.message || `Server responded with ${resp.status}`);
          (err as any).status = errorJson.status || resp.status;
          throw err;
        }

        const data = await resp.json();
        const validated = validateDesignSpec(data);
        if (!validated.success || !validated.data) {
          throw new AppError('unreadable', 'Validation error from extract endpoint');
        }
        return validated.data;
      } else {
        return directAiExtract(images, measurements, signal);
      }
    },
    signal,
    onRetry
  );
}

export async function callAiLocate(
  images: { base64: string; mimeType?: string }[],
  signal: AbortSignal
): Promise<any[]> {
  try {
    const locatePromise = (async () => {
      if (typeof window !== 'undefined') {
        const resp = await fetch('/api/ai/locate', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ images }),
          signal,
        });
        if (!resp.ok) return [];
        return resp.json();
      } else {
        return directAiLocate(images, signal);
      }
    })();
    return await withTimeout(locatePromise, 15000, signal);
  } catch (e) {
    console.warn('Locate step skipped due to timeout or non-fatal issue:', e);
    return [];
  }
}
