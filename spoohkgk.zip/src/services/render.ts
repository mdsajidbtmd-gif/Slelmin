/**
 * DesignSpec and VisualSpec to design.md Markdown renderer
 * Document 2, Section 5.8 & Visual Reproduction Specification T4
 */
import { Box2D, DesignSpec, SourcedValue, VisualSpec } from '../types';

export function slug(text: string): string {
  if (!text) return 'untitled';
  return text
    .toLowerCase()
    .trim()
    .replace(/[^\w\s-]/g, '')
    .replace(/[\s_-]+/g, '-')
    .replace(/^-+|-+$/g, '');
}

function esc(text: string | number | undefined | null): string {
  if (text === undefined || text === null || text === '') return 'unknown';
  const str = String(text).replace(/\|/g, '\\|').replace(/\r?\n/g, ' ').trim();
  return str.length > 0 ? str : 'unknown';
}

function formatHex(v: string | undefined): string {
  if (!v || v === 'unknown') return '`unknown`';
  const clean = v.trim();
  if (clean.startsWith('#')) {
    return `\`${clean.toUpperCase()}\``;
  }
  return `\`#${clean.toUpperCase()}\``;
}

function formatSourced(item?: SourcedValue<any>): string {
  if (!item || item.value === undefined || item.value === null || item.value === '' || item.value === 'unknown') {
    return `unknown [${item?.source || 'unknown'}]`;
  }
  return `${esc(item.value)} [${item.source || 'unknown'}]`;
}

function formatSourcedHex(item?: SourcedValue<string>): string {
  if (!item || !item.value || item.value === 'unknown') {
    return `\`unknown\` [${item?.source || 'unknown'}]`;
  }
  const clean = item.value.trim();
  const hex = clean.startsWith('#') ? clean.toUpperCase() : `#${clean.toUpperCase()}`;
  return `\`${hex}\` [${item.source || 'unknown'}]`;
}

function formatBox(box?: Box2D): string {
  if (!box) return 'unknown';
  const refW = 1440;
  const x = Math.round((box.xmin * refW) / 1000);
  const y = Math.round((box.ymin * refW) / 1000);
  const w = Math.round(((box.xmax - box.xmin) * refW) / 1000);
  const h = Math.round(((box.ymax - box.ymin) * refW) / 1000);
  return `[${box.ymin}, ${box.xmin}, ${box.ymax}, ${box.xmax}] (ref 1440px: x=${x}px, y=${y}px, w=${w}px, h=${h}px)`;
}

export function renderDesignMd(spec: DesignSpec): string {
  const lines: string[] = [];

  // Title and header
  lines.push(`# ${spec.meta.title || 'unknown'} — Style Reference`);
  if (spec.meta.summary && spec.meta.summary !== 'unknown') {
    lines.push(`> ${spec.meta.summary}`);
  }
  lines.push('');
  lines.push(`**Theme:** ${spec.meta.theme || 'unknown'}`);
  lines.push('');
  // Invariant replacement line required by T4:
  lines.push('Measured values are sampled from pixels; estimated and inferred values are labeled.');
  lines.push('');
  if (spec.meta.description && spec.meta.description !== 'unknown') {
    lines.push(spec.meta.description);
    lines.push('');
  }

  const vs = spec.visualSpec;

  if (vs) {
    // --------------------------------------------------------------------------
    // 1. Frame and conversion rule
    // --------------------------------------------------------------------------
    lines.push('## 1. Frame & Conversion Rule');
    lines.push('');
    lines.push(`- **Reference Width:** ${vs.frame.referenceWidth || 1440}px`);
    lines.push(`- **Coordinate System:** ${vs.frame.coordinateSystem || '0-1000 normalized frame converted to a 1440-wide reference frame'}`);
    lines.push(`- **Conversion Rule:** ${vs.frame.conversionRule || 'Reference coordinate X = round(normalized_xmin * 1440 / 1000), width = round((normalized_xmax - normalized_xmin) * 1440 / 1000)'}`);
    if (vs.frame.detectedCrop) {
      lines.push(`- **Detected Inner Crop:** x=${vs.frame.detectedCrop.x}px, y=${vs.frame.detectedCrop.y}px, width=${vs.frame.detectedCrop.width}px, height=${vs.frame.detectedCrop.height}px`);
    }
    lines.push('');

    // --------------------------------------------------------------------------
    // 2. Background
    // --------------------------------------------------------------------------
    lines.push('## 2. Background');
    lines.push('');
    lines.push(`- **Floor Color:** ${formatSourcedHex(vs.background.floor)}`);
    if (vs.background.lift && vs.background.lift.value !== 'none') {
      lines.push(`- **Lift / Glow Color:** ${formatSourcedHex(vs.background.lift)}`);
      if (vs.background.liftFadesAt) {
        lines.push(`- **Lift Fades At:** ${formatSourced(vs.background.liftFadesAt)}`);
      }
    }
    lines.push(`- **Grain:** ${formatSourced(vs.background.grain)}`);
    lines.push(`- **Matte / Gloss:** ${formatSourced(vs.background.matteGloss)}`);
    lines.push(`- **Uniform Canvas:** ${vs.background.uniform ? 'yes' : 'no'}`);
    lines.push(`- **Noise Level:** ${formatSourced(vs.background.noiseLevel)}`);
    lines.push('');

    // --------------------------------------------------------------------------
    // 3. Palette by element role
    // --------------------------------------------------------------------------
    lines.push('## 3. Palette by Element Role');
    lines.push('');
    lines.push('| Role | Name | Value | Token | Usage |');
    lines.push('|------|------|-------|-------|-------|');
    if (vs.paletteByRole && vs.paletteByRole.length > 0) {
      for (const p of vs.paletteByRole) {
        lines.push(`| ${esc(p.role)} | ${esc(p.name)} | ${formatSourcedHex(p.hex)} | \`${esc(p.token)}\` | ${esc(p.usage)} |`);
      }
    } else {
      lines.push('| unknown | unknown | `unknown` [unknown] | `--color-unknown` | unknown |');
    }
    lines.push('');

    // --------------------------------------------------------------------------
    // 4. Copy inventory (verbatim)
    // --------------------------------------------------------------------------
    lines.push('## 4. Copy Inventory (Verbatim)');
    lines.push('');
    lines.push('| ID | Exact Text | Location | Case Style | Source |');
    lines.push('|----|------------|----------|------------|--------|');
    if (vs.copyInventory && vs.copyInventory.length > 0) {
      for (const c of vs.copyInventory) {
        lines.push(`| ${esc(c.id)} | "${esc(c.text)}" | ${esc(c.location)} | ${esc(c.caseStyle)} | ${esc(c.source)} |`);
      }
    } else {
      lines.push('| unknown | "unknown" | unknown | unknown | unknown |');
    }
    lines.push('');

    // --------------------------------------------------------------------------
    // 5. Element inventory
    // --------------------------------------------------------------------------
    lines.push('## 5. Element Inventory');
    lines.push('');
    lines.push('| ID | Kind | Label | Normalized Box [ymin, xmin, ymax, xmax] | Z-Order | Alignment |');
    lines.push('|----|------|-------|-----------------------------------------|---------|-----------|');
    if (vs.elementInventory && vs.elementInventory.length > 0) {
      for (const el of vs.elementInventory) {
        lines.push(`| ${esc(el.id)} | ${esc(el.kind)} | ${esc(el.label)} | ${formatBox(el.box)} | ${formatSourced(el.zOrder)} | ${formatSourced(el.alignment)} |`);
      }
    } else {
      lines.push('| unknown | other | unknown | unknown | unknown [unknown] | unknown [unknown] |');
    }
    lines.push('');

    // --------------------------------------------------------------------------
    // 6. Typography per text element
    // --------------------------------------------------------------------------
    lines.push('## 6. Typography per Text Element');
    lines.push('');
    if (vs.typographyPerElement && vs.typographyPerElement.length > 0) {
      for (const t of vs.typographyPerElement) {
        lines.push(`### ${esc(t.role)}: "${esc(t.sampleText)}" (\`${esc(t.id)}\`)`);
        lines.push(`- **Font Candidates:** ${t.fontCandidates && t.fontCandidates.length > 0 ? t.fontCandidates.join(', ') : 'unknown'}`);
        lines.push(`- **Free Fallback:** ${esc(t.freeFallback)}`);
        lines.push(`- **Size:** ${formatSourced(t.size)}`);
        lines.push(`- **Weight:** ${formatSourced(t.weight)}`);
        lines.push(`- **Line Height:** ${formatSourced(t.lineHeight)}`);
        lines.push(`- **Letter Spacing:** ${formatSourced(t.letterSpacing)}`);
        lines.push(`- **Color:** ${formatSourcedHex(t.color)}`);
        lines.push('');
      }
    } else {
      lines.push('### unknown: "unknown" (`unknown`)');
      lines.push('- **Font Candidates:** unknown');
      lines.push('- **Free Fallback:** unknown');
      lines.push('- **Size:** unknown [unknown]');
      lines.push('- **Weight:** unknown [unknown]');
      lines.push('- **Line Height:** unknown [unknown]');
      lines.push('- **Letter Spacing:** unknown [unknown]');
      lines.push('- **Color:** `unknown` [unknown]');
      lines.push('');
    }

    // --------------------------------------------------------------------------
    // 7. Cards / Containers
    // --------------------------------------------------------------------------
    lines.push('## 7. Cards & Containers');
    lines.push('');
    if (vs.cardsContainers && vs.cardsContainers.length > 0) {
      for (const card of vs.cardsContainers) {
        lines.push(`### ${esc(card.label)} (\`${esc(card.id)}\`)`);
        lines.push(`- **Radius:** ${formatSourced(card.radius)}`);
        lines.push(`- **Padding:** ${formatSourced(card.padding)}`);
        const gradStops = card.gradientStops && card.gradientStops.length > 0
          ? card.gradientStops.map(g => formatSourcedHex(g)).join(', ')
          : 'none';
        lines.push(`- **Gradient Stops:** ${gradStops}`);
        lines.push(`- **Gloss / Reflection:** ${formatSourced(card.gloss)}`);
        lines.push(`- **Shadow:** ${formatSourced(card.shadow)}`);
        lines.push(`- **Rotation:** ${formatSourced(card.rotation)}`);
        lines.push(`- **Overlap:** ${formatSourced(card.overlap)}`);
        lines.push(`- **Crop / Overflow:** ${formatSourced(card.crop)}`);
        lines.push('');
      }
    } else {
      lines.push('*(No discrete cards or containers identified)*');
      lines.push('');
    }

    // --------------------------------------------------------------------------
    // 8. Characters / Illustrations
    // --------------------------------------------------------------------------
    lines.push('## 8. Characters & Illustrations');
    lines.push('');
    if (vs.characters && vs.characters.length > 0) {
      for (const char of vs.characters) {
        lines.push(`### ${esc(char.label)} (\`${esc(char.id)}\`)`);
        lines.push(`- **Description:** ${esc(char.description)}`);
        const colors = char.colors && char.colors.length > 0 ? char.colors.map(c => formatSourcedHex(c)).join(', ') : 'unknown';
        lines.push(`- **Dominant Colors:** ${colors}`);
        lines.push(`- **Materials:** ${formatSourced(char.materials)}`);
        lines.push(`- **Position:** ${formatSourced(char.position)}`);
        lines.push(`- **Crop:** ${formatSourced(char.crop)}`);
        if (char.assetPath) {
          lines.push(`- **Asset Crop:** \`${esc(char.assetPath)}\``);
        }
        lines.push('');
      }
    } else {
      lines.push('*(No character or mascot illustrations observed)*');
      lines.push('');
    }

    // --------------------------------------------------------------------------
    // 9. Props
    // --------------------------------------------------------------------------
    lines.push('## 9. Props');
    lines.push('');
    if (vs.props && vs.props.length > 0) {
      for (const prop of vs.props) {
        lines.push(`### ${esc(prop.label)} (\`${esc(prop.id)}\`)`);
        lines.push(`- **Description:** ${esc(prop.description)}`);
        const colors = prop.colors && prop.colors.length > 0 ? prop.colors.map(c => formatSourcedHex(c)).join(', ') : 'unknown';
        lines.push(`- **Dominant Colors:** ${colors}`);
        lines.push(`- **Materials:** ${formatSourced(prop.materials)}`);
        lines.push(`- **Position:** ${formatSourced(prop.position)}`);
        lines.push(`- **Crop:** ${formatSourced(prop.crop)}`);
        if (prop.assetPath) {
          lines.push(`- **Asset Crop:** \`${esc(prop.assetPath)}\``);
        }
        lines.push('');
      }
    } else {
      lines.push('*(No isolated 3D or visual props observed)*');
      lines.push('');
    }

    // --------------------------------------------------------------------------
    // 10. Icons
    // --------------------------------------------------------------------------
    lines.push('## 10. Icons');
    lines.push('');
    if (vs.icons && vs.icons.length > 0) {
      lines.push('| ID | Name | Label | Size | Color | Position | Description |');
      lines.push('|----|------|-------|------|-------|----------|-------------|');
      for (const ic of vs.icons) {
        lines.push(`| ${esc(ic.id)} | ${esc(ic.name)} | ${esc(ic.label)} | ${formatSourced(ic.size)} | ${formatSourcedHex(ic.color)} | ${formatSourced(ic.position)} | ${esc(ic.description)} |`);
      }
    } else {
      lines.push('*(No standalone icons observed)*');
    }
    lines.push('');

    // --------------------------------------------------------------------------
    // 11. Shadows and shine
    // --------------------------------------------------------------------------
    lines.push('## 11. Shadows & Shine');
    lines.push('');
    if (vs.shadowsAndShine && vs.shadowsAndShine.length > 0) {
      lines.push('| Target | Type | Value | Light Direction |');
      lines.push('|--------|------|-------|-----------------|');
      for (const sh of vs.shadowsAndShine) {
        lines.push(`| ${esc(sh.target)} | ${esc(sh.type)} | ${formatSourced(sh.value)} | ${formatSourced(sh.lightDirection)} |`);
      }
    } else {
      lines.push('*(No explicit shadows or shine effects observed)*');
    }
    lines.push('');

    // --------------------------------------------------------------------------
    // 12. Motion (always inferred)
    // --------------------------------------------------------------------------
    lines.push('## 12. Motion (Inferred)');
    lines.push('');
    if (vs.motion && vs.motion.length > 0) {
      for (const m of vs.motion) {
        lines.push(`- **${esc(m.element)}** (${esc(m.trigger)}): ${esc(m.description)} [inferred]`);
      }
    } else {
      lines.push('- **Interactions**: Subtle easing transitions on hover states [inferred]');
    }
    lines.push('');

    // --------------------------------------------------------------------------
    // 13. Do and Don't
    // --------------------------------------------------------------------------
    lines.push("## 13. Do's & Don'ts");
    lines.push('');
    const dos = vs.dosAndDonts?.dos || spec.dosAndDonts?.dos || [];
    const donts = vs.dosAndDonts?.donts || spec.dosAndDonts?.donts || [];

    if (dos.length > 0) {
      lines.push('### Do');
      for (const d of dos) lines.push(`- ${esc(d)}`);
      lines.push('');
    }
    if (donts.length > 0) {
      lines.push("### Don't");
      for (const d of donts) lines.push(`- ${esc(d)}`);
      lines.push('');
    }
  } else {
    // Legacy spec rendering without visualSpec (guarantees old saved results open cleanly)
    lines.push('## Tokens — Colors');
    lines.push('');
    lines.push('| Name | Value | Token | Role |');
    lines.push('|------|-------|-------|------|');
    for (const c of spec.colors || []) {
      lines.push(`| ${esc(c.name)} | ${formatHex(c.value)} | \`${esc(c.token)}\` | ${esc(c.role)} |`);
    }
    lines.push('');

    lines.push('## Tokens — Typography');
    lines.push('');
    const fonts = [spec.typography.primaryFont, spec.typography.secondaryFont, spec.typography.utilityFont].filter(Boolean);
    for (const font of fonts) {
      if (!font) continue;
      const fontSlug = slug(font.name);
      lines.push(`### ${esc(font.name)} — ${esc(font.role)} · \`--font-${fontSlug}\``);
      if (font.substitute) lines.push(`- **Substitute:** ${esc(font.substitute)}`);
      if (font.weights && font.weights.length > 0) lines.push(`- **Weights:** ${font.weights.join(', ')}`);
      if (font.sizes && font.sizes.length > 0) lines.push(`- **Sizes:** ${font.sizes.join(', ')}`);
      if (font.lineHeight) lines.push(`- **Line height:** ${esc(font.lineHeight)}`);
      if (font.letterSpacing) lines.push(`- **Letter spacing:** ${esc(font.letterSpacing)}`);
      lines.push('');
    }

    if (spec.typography.typeScale && spec.typography.typeScale.length > 0) {
      lines.push('### Type Scale');
      lines.push('');
      lines.push('| Role | Family | Weight | Size | Line Height | Letter Spacing | Token |');
      lines.push('|------|--------|--------|------|-------------|----------------|-------|');
      for (const item of spec.typography.typeScale) {
        lines.push(`| ${esc(item.role)} | ${esc(item.family)} | ${esc(item.weight)} | ${esc(item.size)} | ${esc(item.lineHeight)} | ${esc(item.letterSpacing)} | \`${esc(item.token)}\` |`);
      }
      lines.push('');
    }

    lines.push('## Tokens — Spacing & Shapes');
    lines.push('');
    lines.push(`**Base unit:** ${spec.spacing.baseUnit || 4}px`);
    lines.push(`**Density:** ${spec.spacing.density || 'unknown'}`);
    lines.push('');

    if (spec.spacing.scale && spec.spacing.scale.length > 0) {
      lines.push('### Spacing Scale');
      lines.push('');
      lines.push('| Name | Value | Token |');
      lines.push('|------|-------|-------|');
      for (const s of spec.spacing.scale) {
        lines.push(`| ${esc(s.name)} | ${esc(s.value)} | \`${esc(s.token)}\` |`);
      }
      lines.push('');
    }

    if (spec.spacing.radii && spec.spacing.radii.length > 0) {
      lines.push('### Border Radius');
      lines.push('');
      lines.push('| Element | Value | Token |');
      lines.push('|---------|-------|-------|');
      for (const r of spec.spacing.radii) {
        lines.push(`| ${esc(r.element)} | ${esc(r.value)} | \`${esc(r.token || `--radius-${slug(r.element)}`)}\` |`);
      }
      lines.push('');
    }

    if (spec.spacing.shadows && spec.spacing.shadows.length > 0) {
      lines.push('### Shadows');
      lines.push('');
      lines.push('| Name | Value | Token |');
      lines.push('|------|-------|-------|');
      for (const sh of spec.spacing.shadows) {
        lines.push(`| ${esc(sh.name)} | ${esc(sh.value)} | \`${esc(sh.token)}\` |`);
      }
      lines.push('');
    }

    if (spec.surfaces && spec.surfaces.length > 0) {
      lines.push('## Surfaces');
      lines.push('');
      lines.push('| Level | Name | Value | Purpose |');
      lines.push('|-------|------|-------|---------|');
      for (const surf of spec.surfaces) {
        lines.push(`| ${esc(surf.level)} | ${esc(surf.name)} | ${formatHex(surf.value)} | ${esc(surf.purpose)} |`);
      }
      lines.push('');
    }

    if (spec.components && spec.components.length > 0) {
      lines.push('## Components');
      lines.push('');
      for (const comp of spec.components) {
        lines.push(`### ${esc(comp.name)}`);
        lines.push(`**Role:** ${esc(comp.role)}`);
        lines.push('');
        lines.push(esc(comp.description));
        lines.push('');
      }
    }

    if (spec.dosAndDonts) {
      lines.push("## Do's and Don'ts");
      lines.push('');
      if (spec.dosAndDonts.dos && spec.dosAndDonts.dos.length > 0) {
        lines.push('### Do');
        for (const d of spec.dosAndDonts.dos) lines.push(`- ${esc(d)}`);
        lines.push('');
      }
      if (spec.dosAndDonts.donts && spec.dosAndDonts.donts.length > 0) {
        lines.push("### Don't");
        for (const d of spec.dosAndDonts.donts) lines.push(`- ${esc(d)}`);
        lines.push('');
      }
    }
  }

  return lines.join('\n');
}
