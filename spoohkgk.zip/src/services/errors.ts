/**
 * Application errors and mapping
 * Document 2, Section 5.5
 */

export const ERROR_MESSAGES: Record<string, string> = {
  quota: 'The service is busy. Free tier quota is exhausted. Please try again shortly.',
  network: 'Network connection issue or timeout. Please check your internet and try again.',
  ai_config: 'The AI service is not set up correctly. Check the API key.',
  unreadable: 'We could not read enough detail from this image. Please send a clearer screenshot.',
  adult_or_unsafe: 'We cannot process this image due to safety policies.',
  cancelled: 'Operation was cancelled.',
  not_website: 'We could not detect a website in this image. Please upload a clear website screenshot.',
  blurry: 'The screenshot is too blurry to extract design tokens.',
  too_small: 'Image dimensions are too small (minimum 800x300).',
  too_large: 'File size exceeds the 10 MB limit.',
  too_many_files: 'Maximum 8 screenshots allowed per run.',
  storage: 'Local or cloud storage error occurred.',
};

export class AppError extends Error {
  code: string;

  constructor(code: string, message?: string) {
    super(message || ERROR_MESSAGES[code] || `Application error: ${code}`);
    this.name = 'AppError';
    this.code = code;
    Object.setPrototypeOf(this, AppError.prototype);
  }
}

export function getErrorMessage(code: string): string {
  return ERROR_MESSAGES[code] || `An issue occurred (${code}). Please try again.`;
}

export function mapError(err: any): AppError {
  if (err instanceof AppError) {
    return err;
  }

  if (err?.code && ERROR_MESSAGES[err.code]) {
    return new AppError(err.code, err.message);
  }

  const status = err?.status || err?.statusCode || (typeof err?.message === 'string' && err.message.match(/\[(4\d\d|5\d\d)\]/)?.[1]);

  if (status == 429 || status == 503 || status == 504) {
    return new AppError('quota', ERROR_MESSAGES.quota);
  }

  if (status == 401 || status == 403) {
    return new AppError('ai_config', 'The AI service is not set up correctly. Check the API key.');
  }

  if (status == 400) {
    return new AppError('unreadable', 'We could not read enough detail from this image. Please send a clearer screenshot.');
  }

  const msg = String(err?.message || err || '').toLowerCase();

  if (msg.includes('abort') || msg.includes('cancelled') || msg.includes('canceled')) {
    return new AppError('cancelled');
  }

  if (msg.includes('safety') || msg.includes('blocked') || msg.includes('harm')) {
    return new AppError('adult_or_unsafe');
  }

  if (msg.includes('quota') || msg.includes('rate limit') || msg.includes('resource_exhausted')) {
    return new AppError('quota');
  }

  if (msg.includes('api key') || msg.includes('unauthenticated') || msg.includes('permission denied')) {
    return new AppError('ai_config');
  }

  return new AppError('network', err?.message || ERROR_MESSAGES.network);
}
