/**
 * Pipeline orchestrator v2.0.0
 * Document 2, Section 5.4 & Visual Reproduction Specification T1-T10
 */
import { nanoid } from 'nanoid';
import { MAX_FILES, TALL_RATIO, SEGMENT_RATIO, MAX_SEGMENTS } from '../config';
import { AppError, getErrorMessage } from './errors';
import { computeFilesHash, makeCacheKey } from './hash';
import { processUploadFile, PreparedImage } from './prepare';
import { measureImages } from './measure';
import { callAiAnalyze, callAiExtract, callAiLocate } from './ai';
import { renderDesignMd } from './render';
import { cropAndStoreAssets } from './assets';
import { saveResult, getCachedResultId, getResult, setSiteQueue } from '../storage/local';
import { PipelineEvent, PipelineOptions, SiteGroup, Result, ResultImage, Box2D, Measurements } from '../types';

/**
 * Splits tall screenshots into overlapping vertical tiles so text is never downscaled into unreadability.
 */
async function splitTallImageIntoTiles(
  prepared: PreparedImage
): Promise<{ base64: string; mimeType: string }[]> {
  if (typeof window === 'undefined' || typeof document === 'undefined') {
    return [{ base64: prepared.aiBase64, mimeType: prepared.aiMimeType || 'image/png' }];
  }

  const { width, height, dataUrl } = prepared;
  const ratio = height / (width || 1);

  if (ratio <= TALL_RATIO) {
    return [{ base64: prepared.aiBase64, mimeType: prepared.aiMimeType || 'image/png' }];
  }

  return new Promise((resolve) => {
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => {
      const tileHeight = Math.round(width * SEGMENT_RATIO);
      const overlap = Math.round(tileHeight * 0.2); // 20% overlap
      const step = tileHeight - overlap;
      const tiles: { base64: string; mimeType: string }[] = [];

      let y = 0;
      let count = 0;

      while (y < height && count < 3) {
        const currentTileH = Math.min(tileHeight, height - y);
        const canvas = document.createElement('canvas');
        canvas.width = width;
        canvas.height = currentTileH;
        const ctx = canvas.getContext('2d');
        if (ctx) {
          ctx.drawImage(img, 0, y, width, currentTileH, 0, 0, width, currentTileH);
          const tileDataUrl = canvas.toDataURL('image/png');
          tiles.push({
            base64: tileDataUrl.replace(/^data:image\/[a-z0-9+.-]+;base64,/, ''),
            mimeType: 'image/png',
          });
        }
        y += step;
        count++;
        if (y + currentTileH >= height) break;
      }

      resolve(tiles.length > 0 ? tiles : [{ base64: prepared.aiBase64, mimeType: prepared.aiMimeType || 'image/png' }]);
    };
    img.onerror = () => {
      resolve([{ base64: prepared.aiBase64, mimeType: prepared.aiMimeType || 'image/png' }]);
    };
    img.src = dataUrl;
  });
}

export async function runPipeline(files: File[], opts: PipelineOptions): Promise<void> {
  const { signal, onEvent, requestChoice } = opts;

  try {
    if (signal.aborted) throw new AppError('cancelled');

    // ----------------------------------------------------
    // STEP 1: CHECK (hash, validate client rules, prepare)
    // ----------------------------------------------------
    onEvent({ type: 'step', step: 'check', status: 'active' });

    if (files.length === 0) {
      throw new AppError('network', 'No files provided.');
    }

    if (files.length > MAX_FILES) {
      onEvent({
        type: 'rejected',
        items: files.slice(MAX_FILES).map((f) => ({
          fileName: f.name,
          code: 'too_many_files',
        })),
      });
      return;
    }

    // Process and validate files
    const preparedList: PreparedImage[] = [];
    const clientRejectedItems: { fileName: string; code: string; reason?: string }[] = [];

    for (const file of files) {
      if (signal.aborted) throw new AppError('cancelled');
      const prepared = await processUploadFile(file);
      if (prepared.issueCode) {
        clientRejectedItems.push({
          fileName: file.name,
          code: prepared.issueCode,
          reason: prepared.issueReason || getErrorMessage(prepared.issueCode),
        });
      }
      preparedList.push(prepared);
    }

    if (clientRejectedItems.length > 0) {
      onEvent({ type: 'rejected', items: clientRejectedItems });
      return;
    }

    // Compute deterministic cache key from input file contents
    const hash = await computeFilesHash(files);
    const cacheKey = makeCacheKey(hash);

    // Check IndexedDB cache
    const cachedId = await getCachedResultId(cacheKey);
    if (cachedId) {
      const existing = await getResult(cachedId);
      if (existing) {
        onEvent({ type: 'step', step: 'check', status: 'done' });
        onEvent({ type: 'cache_hit', resultId: cachedId });
        onEvent({ type: 'done', resultIds: [cachedId] });
        return;
      }
    }

    onEvent({ type: 'step', step: 'check', status: 'done' });

    // ----------------------------------------------------
    // STEP 2: MEASURE (initial global measurement)
    // ----------------------------------------------------
    if (signal.aborted) throw new AppError('cancelled');
    onEvent({ type: 'step', step: 'measure', status: 'active' });

    const globalMeasurements = await measureImages(
      preparedList.map((p) => ({
        width: p.width,
        height: p.height,
        dataUrl: p.dataUrl,
      }))
    );

    onEvent({ type: 'step', step: 'measure', status: 'done' });

    // ----------------------------------------------------
    // STEP 3: ANALYZE (verify website, multi-site detection)
    // ----------------------------------------------------
    if (signal.aborted) throw new AppError('cancelled');
    onEvent({ type: 'step', step: 'analyze', status: 'active' });

    const analyzeResult = await callAiAnalyze(
      preparedList.map((p) => ({
        base64: p.aiBase64,
        mimeType: p.aiMimeType || 'image/png',
      })),
      signal,
      (inSeconds, attempt) => {
        onEvent({ type: 'retry', inSeconds, attempt });
      }
    );

    if (!analyzeResult.isWebsite) {
      const code = analyzeResult.rejectionCode || 'not_website';
      const reason = analyzeResult.rejectionReason || getErrorMessage(code);
      onEvent({
        type: 'rejected',
        items: files.map((f) => ({ fileName: f.name, code, reason })),
      });
      return;
    }

    let sitesToProcess: SiteGroup[] = [];
    if (analyzeResult.sites && analyzeResult.sites.length > 1) {
      // Prompt user to choose
      const choice = await requestChoice(analyzeResult.sites);
      const chosenSiteIds = choice.siteIds;

      sitesToProcess = analyzeResult.sites.filter((s) => chosenSiteIds.includes(s.id));
      const unchosenSites = analyzeResult.sites.filter((s) => !chosenSiteIds.includes(s.id));

      if (unchosenSites.length > 0) {
        await setSiteQueue(unchosenSites);
      } else {
        await setSiteQueue([]);
      }
    } else if (analyzeResult.sites && analyzeResult.sites.length === 1) {
      sitesToProcess = analyzeResult.sites;
      await setSiteQueue([]);
    } else {
      // T1: No default site fabrication with fake sections
      sitesToProcess = [
        {
          id: 'site-1',
          label: 'unknown',
          description: 'unknown',
          sections: [],
          imageIndices: preparedList.map((_, i) => i),
        },
      ];
      await setSiteQueue([]);
    }

    onEvent({ type: 'step', step: 'analyze', status: 'done' });

    // ----------------------------------------------------
    // STEP 4: EXTRACT (Per-Site Measurement, Locate, Zoom & Extract)
    // ----------------------------------------------------
    if (signal.aborted) throw new AppError('cancelled');
    onEvent({ type: 'step', step: 'extract', status: 'active' });

    const createdResultIds: string[] = [];

    for (const site of sitesToProcess) {
      if (signal.aborted) throw new AppError('cancelled');

      // Select images for this site
      const siteImages = (site.imageIndices || [0])
        .filter((idx) => idx >= 0 && idx < preparedList.length)
        .map((idx) => preparedList[idx]);

      const effectiveImages = siteImages.length > 0 ? siteImages : preparedList;

      // T7 & T8: Check if first image is tall screenshot
      const primaryImg = effectiveImages[0];
      const tiles = await splitTallImageIntoTiles(primaryImg);

      // T7: Locate elements pass on primary image
      let detectedBoxes: Box2D[] = [];
      try {
        const located = await callAiLocate(
          [{ base64: primaryImg.aiBase64, mimeType: primaryImg.aiMimeType || 'image/png' }],
          signal
        );
        if (Array.isArray(located)) {
          detectedBoxes = located
            .map((el) => {
              const b = el.box_2d || el.box;
              if (Array.isArray(b) && b.length === 4) {
                return { ymin: b[0], xmin: b[1], ymax: b[2], xmax: b[3] };
              }
              return null;
            })
            .filter((b): b is Box2D => Boolean(b));
        }
      } catch (e) {
        console.warn('Locate pass skipped or non-fatal:', e);
      }

      // T9: Compute measurements PER SITE's images with detected region boxes (or use global if single site)
      const siteMeasurements: Measurements =
        detectedBoxes.length === 0 && effectiveImages.length === preparedList.length
          ? globalMeasurements
          : await measureImages(
              effectiveImages.map((p) => ({
                width: p.width,
                height: p.height,
                dataUrl: p.dataUrl,
              })),
              detectedBoxes.slice(0, 8)
            );

      // Prepare images payload (using tiles if tall, or original prepared images)
      const extractImagesPayload =
        tiles.length > 1
          ? tiles
          : effectiveImages.map((p) => ({
              base64: p.aiBase64,
              mimeType: p.aiMimeType || 'image/png',
            }));

      // Extract tokens + VisualSpec in one call
      const spec = await callAiExtract(
        extractImagesPayload,
        siteMeasurements,
        signal,
        (inSeconds, attempt) => {
          onEvent({ type: 'retry', inSeconds, attempt });
        }
      );

      // Overwrite meta title if site label is specific
      if (site.label && site.label !== 'Untitled Site' && site.label !== 'unknown') {
        spec.meta.title = site.label.slice(0, 60);
      }

      // ----------------------------------------------------
      // STEP 5: VALIDATE, RENDER & ASSET CROP (Save)
      // ----------------------------------------------------
      if (signal.aborted) throw new AppError('cancelled');
      onEvent({ type: 'step', step: 'validate', status: 'active' });

      const newId = nanoid(10);

      // T10: Crop native-resolution assets and store locally in IndexedDB
      if (primaryImg.dataUrl) {
        try {
          await cropAndStoreAssets(newId, primaryImg.dataUrl, spec);
        } catch (e) {
          console.warn('Asset crop non-fatal:', e);
        }
      }

      const markdown = renderDesignMd(spec);

      const resultImages: ResultImage[] = effectiveImages.map((p) => ({
        name: p.file.name,
        width: p.width,
        height: p.height,
        thumbDataUrl: p.thumbDataUrl,
        dataUrl: p.dataUrl,
        cropRect: siteMeasurements.cropRect,
      }));

      const resultObj: Result = {
        id: newId,
        createdAt: Date.now(),
        cacheKey: sitesToProcess.length === 1 ? cacheKey : `${cacheKey}_${site.id}`,
        title: spec.meta.title,
        tags: {
          industry: spec.meta.industry !== 'unknown' ? [spec.meta.industry] : [],
          style: spec.meta.styleTags || [],
          sections: spec.meta.sections || [],
        },
        markdown,
        spec,
        images: resultImages,
      };

      await saveResult(resultObj);
      createdResultIds.push(newId);
    }

    onEvent({ type: 'step', step: 'extract', status: 'done' });
    onEvent({ type: 'step', step: 'validate', status: 'done' });
    onEvent({ type: 'done', resultIds: createdResultIds });
  } catch (err: any) {
    if (signal.aborted || err?.code === 'cancelled' || err?.message === 'cancelled') {
      onEvent({ type: 'error', error: new AppError('cancelled') });
    } else {
      onEvent({
        type: 'error',
        error: err instanceof AppError ? err : new AppError('network', err?.message),
      });
    }
  }
}
