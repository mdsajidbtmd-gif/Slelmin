/**
 * Local asset cropping & fflate ZIP packaging
 * Document 2, Section 5.1 & Visual Reproduction Specification T10
 */
import { set, get } from 'idb-keyval';
import { zipSync } from 'fflate';
import { Box2D, DesignSpec, Result } from '../types';

export interface LocalAsset {
  id: string;
  name: string;
  mime: string;
  data: Uint8Array;
}

/**
 * Crops native-resolution elements from canvas and stores them in IndexedDB
 */
export async function cropAndStoreAssets(
  resultId: string,
  dataUrl: string,
  spec: DesignSpec
): Promise<string[]> {
  if (typeof window === 'undefined' || typeof document === 'undefined') return [];
  if (!spec.visualSpec) return [];

  const vs = spec.visualSpec;
  const itemsToCrop: { id: string; box?: Box2D }[] = [
    ...(vs.characters || []).map((c) => ({ id: c.id, box: c.box })),
    ...(vs.props || []).map((p) => ({ id: p.id, box: p.box })),
    ...(vs.icons || []).map((i) => ({ id: i.id, box: i.box })),
  ];

  const validItems = itemsToCrop.filter(
    (item) =>
      item.box &&
      item.box.xmax > item.box.xmin &&
      item.box.ymax > item.box.ymin &&
      item.box.xmax <= 1000 &&
      item.box.ymax <= 1000
  );

  if (validItems.length === 0) return [];

  return new Promise((resolve) => {
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = async () => {
      const nw = img.naturalWidth || img.width;
      const nh = img.naturalHeight || img.height;
      const storedAssetIds: string[] = [];
      const assetMap: Record<string, string> = {};

      for (const item of validItems) {
        const box = item.box!;
        const sx = Math.max(0, Math.floor((box.xmin * nw) / 1000));
        const sy = Math.max(0, Math.floor((box.ymin * nh) / 1000));
        const sw = Math.max(1, Math.ceil(((box.xmax - box.xmin) * nw) / 1000));
        const sh = Math.max(1, Math.ceil(((box.ymax - box.ymin) * nh) / 1000));

        const canvas = document.createElement('canvas');
        canvas.width = sw;
        canvas.height = sh;
        const ctx = canvas.getContext('2d');
        if (ctx) {
          ctx.drawImage(img, sx, sy, sw, sh, 0, 0, sw, sh);
          const cropDataUrl = canvas.toDataURL('image/png');
          assetMap[`assets/${item.id}.png`] = cropDataUrl;
          storedAssetIds.push(item.id);

          // Update assetPath on matching elements
          const char = vs.characters?.find((c) => c.id === item.id);
          if (char) char.assetPath = `assets/${item.id}.png`;

          const prop = vs.props?.find((p) => p.id === item.id);
          if (prop) prop.assetPath = `assets/${item.id}.png`;

          const icon = vs.icons?.find((i) => i.id === item.id);
          if (icon) icon.assetPath = `assets/${item.id}.png`;
        }
      }

      await set(`loupe_assets_${resultId}`, assetMap);
      resolve(storedAssetIds);
    };
    img.onerror = () => resolve([]);
    img.src = dataUrl;
  });
}

function dataUrlToUint8Array(dataUrl: string): Uint8Array {
  const base64 = dataUrl.replace(/^data:image\/[a-z0-9+.-]+;base64,/, '');
  const binary = atob(base64);
  const len = binary.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binary.charCodeAt(i);
  }
  return bytes;
}

/**
 * Downloads a ZIP containing design.md plus all cropped assets using fflate
 */
export async function downloadSpecWithAssetsZip(result: Result): Promise<void> {
  const assets: Record<string, string> =
    (await get(`loupe_assets_${result.id}`)) || {};

  const zipFiles: Record<string, Uint8Array> = {
    'design.md': new TextEncoder().encode(result.markdown),
  };

  for (const [path, dataUrl] of Object.entries(assets)) {
    try {
      zipFiles[path] = dataUrlToUint8Array(dataUrl);
    } catch (e) {
      console.warn('Could not encode asset', path, e);
    }
  }

  const zipBuffer = zipSync(zipFiles);
  const blob = new Blob([zipBuffer.buffer as ArrayBuffer], { type: 'application/zip' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  const slug = (result.title || 'design').toLowerCase().replace(/[^a-z0-9]/g, '-').replace(/-+/g, '-');
  a.download = `${slug}-design-with-assets.zip`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}
