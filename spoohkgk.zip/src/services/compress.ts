/**
 * Image compression for storage and sharing
 * Document 2, Section 5.10
 */
import { AppError } from './errors';

export interface CompressOptions {
  maxSide: number;
  maxBytes: number;
}

export interface CompressResult {
  dataUrl: string;
  width: number;
  height: number;
  bytes: number;
}

function blobToImage(blob: Blob): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const url = URL.createObjectURL(blob);
    const img = new Image();
    img.onload = () => {
      URL.revokeObjectURL(url);
      resolve(img);
    };
    img.onerror = () => {
      URL.revokeObjectURL(url);
      reject(new AppError('storage', 'Failed to read image blob for compression'));
    };
    img.src = url;
  });
}

export async function compressImage(
  blob: Blob,
  opts: CompressOptions
): Promise<CompressResult> {
  const img = await blobToImage(blob);
  const origW = img.naturalWidth || img.width;
  const origH = img.naturalHeight || img.height;

  const qualities = [0.85, 0.75, 0.65, 0.5];
  const sideAttempts = [opts.maxSide, Math.min(opts.maxSide, 1400), 1000, 600];

  const canvas = document.createElement('canvas');

  for (const maxSide of sideAttempts) {
    const scale = Math.min(maxSide / origW, maxSide / origH, 1);
    const targetW = Math.max(1, Math.round(origW * scale));
    const targetH = Math.max(1, Math.round(origH * scale));

    canvas.width = targetW;
    canvas.height = targetH;
    const ctx = canvas.getContext('2d');
    if (!ctx) continue;

    ctx.clearRect(0, 0, targetW, targetH);
    ctx.drawImage(img, 0, 0, targetW, targetH);

    // Try webp first, then jpeg
    for (const format of ['image/webp', 'image/jpeg']) {
      for (const q of qualities) {
        const dataUrl = canvas.toDataURL(format, q);
        const base64Len = dataUrl.length - dataUrl.indexOf(',') - 1;
        const bytes = Math.round((base64Len * 3) / 4);

        if (bytes <= opts.maxBytes) {
          return {
            dataUrl,
            width: targetW,
            height: targetH,
            bytes,
          };
        }
      }
    }
  }

  // Final fallback: tiny scale
  const scale = Math.min(480 / origW, 480 / origH, 1);
  const targetW = Math.max(1, Math.round(origW * scale));
  const targetH = Math.max(1, Math.round(origH * scale));
  canvas.width = targetW;
  canvas.height = targetH;
  const ctx = canvas.getContext('2d');
  if (ctx) {
    ctx.drawImage(img, 0, 0, targetW, targetH);
    const dataUrl = canvas.toDataURL('image/jpeg', 0.5);
    const base64Len = dataUrl.length - dataUrl.indexOf(',') - 1;
    const bytes = Math.round((base64Len * 3) / 4);
    if (bytes <= opts.maxBytes * 1.5) {
      return {
        dataUrl,
        width: targetW,
        height: targetH,
        bytes,
      };
    }
  }

  throw new AppError('storage', 'Image could not be compressed below maximum allowed size.');
}
