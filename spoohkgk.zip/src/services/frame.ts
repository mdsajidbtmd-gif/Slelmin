/**
 * Presentation mat & uniform border detection and cropping
 * Document 2, Section 5.1 & Visual Reproduction Specification T3
 */

export interface FrameCropResult {
  x: number;
  y: number;
  width: number;
  height: number;
  hasBorder: boolean;
  matColor?: string;
}

export interface PixelBuffer {
  width: number;
  height: number;
  data: Uint8ClampedArray | Uint8Array;
}

function colorDistance(r1: number, g1: number, b1: number, r2: number, g2: number, b2: number): number {
  return Math.sqrt((r1 - r2) ** 2 + (g1 - g2) ** 2 + (b1 - b2) ** 2);
}

function toHex(r: number, g: number, b: number): string {
  const h = (n: number) => Math.max(0, Math.min(255, Math.round(n))).toString(16).padStart(2, '0').toUpperCase();
  return `#${h(r)}${h(g)}${h(b)}`;
}

/**
 * Scans inward from top, bottom, left, and right to detect a uniform presentation mat / border.
 * Returns the inner bounding box of the actual design area.
 */
export function detectFrameCrop(buffer: PixelBuffer): FrameCropResult {
  const { width, height, data } = buffer;

  if (width < 30 || height < 30) {
    return { x: 0, y: 0, width, height, hasBorder: false };
  }

  const getPixel = (x: number, y: number): [number, number, number, number] => {
    const idx = (y * width + x) * 4;
    return [data[idx], data[idx + 1], data[idx + 2], data[idx + 3]];
  };

  // Sample the 4 corners
  const tl = getPixel(1, 1);
  const tr = getPixel(width - 2, 1);
  const bl = getPixel(1, height - 2);
  const br = getPixel(width - 2, height - 2);

  // If corners are not reasonably uniform, there's no solid frame mat around the image
  const cornerTol = 28;
  const d1 = colorDistance(tl[0], tl[1], tl[2], tr[0], tr[1], tr[2]);
  const d2 = colorDistance(tl[0], tl[1], tl[2], bl[0], bl[1], bl[2]);
  const d3 = colorDistance(tl[0], tl[1], tl[2], br[0], br[1], br[2]);

  const cornersMatch = d1 < cornerTol && d2 < cornerTol && d3 < cornerTol;
  if (!cornersMatch) {
    return { x: 0, y: 0, width, height, hasBorder: false };
  }

  const matR = Math.round((tl[0] + tr[0] + bl[0] + br[0]) / 4);
  const matG = Math.round((tl[1] + tr[1] + bl[1] + br[1]) / 4);
  const matB = Math.round((tl[2] + tr[2] + bl[2] + br[2]) / 4);

  const diffThreshold = 22;
  const maxInwardScanY = Math.floor(height * 0.4);
  const maxInwardScanX = Math.floor(width * 0.4);

  // Scan Top -> Bottom
  let top = 0;
  for (let y = 0; y < maxInwardScanY; y++) {
    let nonMatCount = 0;
    // Sample across row
    for (let x = 0; x < width; x += 2) {
      const [r, g, b] = getPixel(x, y);
      if (colorDistance(r, g, b, matR, matG, matB) > diffThreshold) {
        nonMatCount++;
      }
    }
    // If more than 3% of row deviates, design starts
    if (nonMatCount > (width / 2) * 0.03) {
      top = y;
      break;
    }
  }

  // Scan Bottom -> Top
  let bottom = height - 1;
  for (let y = height - 1; y >= height - maxInwardScanY; y--) {
    let nonMatCount = 0;
    for (let x = 0; x < width; x += 2) {
      const [r, g, b] = getPixel(x, y);
      if (colorDistance(r, g, b, matR, matG, matB) > diffThreshold) {
        nonMatCount++;
      }
    }
    if (nonMatCount > (width / 2) * 0.03) {
      bottom = y;
      break;
    }
  }

  // Scan Left -> Right
  let left = 0;
  for (let x = 0; x < maxInwardScanX; x++) {
    let nonMatCount = 0;
    for (let y = top; y <= bottom; y += 2) {
      const [r, g, b] = getPixel(x, y);
      if (colorDistance(r, g, b, matR, matG, matB) > diffThreshold) {
        nonMatCount++;
      }
    }
    if (nonMatCount > ((bottom - top + 1) / 2) * 0.03) {
      left = x;
      break;
    }
  }

  // Scan Right -> Left
  let right = width - 1;
  for (let x = width - 1; x >= width - maxInwardScanX; x--) {
    let nonMatCount = 0;
    for (let y = top; y <= bottom; y += 2) {
      const [r, g, b] = getPixel(x, y);
      if (colorDistance(r, g, b, matR, matG, matB) > diffThreshold) {
        nonMatCount++;
      }
    }
    if (nonMatCount > ((bottom - top + 1) / 2) * 0.03) {
      right = x;
      break;
    }
  }

  const cropW = right - left + 1;
  const cropH = bottom - top + 1;

  // Check if meaningful border was detected on edges (at least 4px total margin)
  const totalMarginX = left + (width - 1 - right);
  const totalMarginY = top + (height - 1 - bottom);

  if ((totalMarginX >= 6 || totalMarginY >= 6) && cropW >= 50 && cropH >= 50) {
    return {
      x: left,
      y: top,
      width: cropW,
      height: cropH,
      hasBorder: true,
      matColor: toHex(matR, matG, matB),
    };
  }

  return { x: 0, y: 0, width, height, hasBorder: false };
}

/**
 * Extracts a sub-rectangle pixel buffer from a source buffer.
 */
export function cropPixelBuffer(
  source: PixelBuffer,
  crop: { x: number; y: number; width: number; height: number }
): PixelBuffer {
  const { x, y, width, height } = crop;
  const out = new Uint8ClampedArray(width * height * 4);

  for (let row = 0; row < height; row++) {
    const srcRow = y + row;
    if (srcRow < 0 || srcRow >= source.height) continue;
    const srcStart = (srcRow * source.width + x) * 4;
    const srcEnd = srcStart + width * 4;
    const dstStart = row * width * 4;
    out.set(source.data.subarray(srcStart, srcEnd), dstStart);
  }

  return { width, height, data: out };
}
