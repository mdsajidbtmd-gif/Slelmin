/**
 * Zod validation schemas and normalization for AnalyzeResult, DesignSpec, and VisualSpec
 * Document 2, Section 5.1 & Visual Reproduction Specification T1 & T4
 */
import { z } from 'zod';
import { AnalyzeResult, DesignSpec, VisualSpec } from '../types';

export const SiteGroupSchema = z.object({
  id: z.string().default('site-1'),
  label: z.string().default('unknown'),
  description: z.string().default('unknown'),
  sections: z.array(z.string()).default([]),
  imageIndices: z.array(z.number()).default([0]),
});

export const AnalyzeResultSchema = z.object({
  isWebsite: z.boolean().default(true),
  rejectionCode: z.string().nullable().optional(),
  rejectionReason: z.string().nullable().optional(),
  sites: z.array(SiteGroupSchema).default([]),
});

export const ColorTokenSchema = z.object({
  name: z.string().default('unknown'),
  value: z.string().default('unknown'),
  token: z.string().default('--color-custom'),
  role: z.string().default('unknown'),
});

export const TypeScaleItemSchema = z.object({
  role: z.string().default('unknown'),
  family: z.string().default('unknown'),
  weight: z.union([z.number(), z.string()]).default('unknown'),
  size: z.union([z.number(), z.string()]).default('unknown'),
  lineHeight: z.union([z.number(), z.string()]).default('unknown'),
  letterSpacing: z.union([z.number(), z.string()]).default('unknown'),
  token: z.string().default('--text-custom'),
});

export const TypefaceInfoSchema = z.object({
  name: z.string().default('unknown'),
  substitute: z.string().default('unknown'),
  role: z.string().default('unknown'),
  weights: z.array(z.union([z.number(), z.string()])).default([]),
  sizes: z.array(z.union([z.number(), z.string()])).default([]),
  lineHeight: z.string().default('unknown'),
  letterSpacing: z.string().default('unknown'),
  token: z.string().default('--font-custom'),
});

export const SpacingItemSchema = z.object({
  name: z.string().default('unknown'),
  value: z.string().default('unknown'),
  token: z.string().default('--spacing-custom'),
});

export const RadiusItemSchema = z.object({
  element: z.string().default('unknown'),
  value: z.string().default('unknown'),
  token: z.string().optional(),
});

export const ElevationItemSchema = z.object({
  name: z.string().default('unknown'),
  value: z.string().default('unknown'),
  token: z.string().default('--shadow-custom'),
});

export const SurfaceItemSchema = z.object({
  level: z.number().default(0),
  name: z.string().default('unknown'),
  value: z.string().default('unknown'),
  purpose: z.string().default('unknown'),
});

export const ComponentSpecSchema = z.object({
  name: z.string().default('unknown'),
  role: z.string().default('unknown'),
  description: z.string().default('unknown'),
  props: z.record(z.string(), z.string()).optional(),
  tokensUsed: z.array(z.string()).optional(),
});

// Source tagging helper
export const ValueSourceSchema = z.enum(['measured', 'estimated', 'inferred', 'unknown']).default('unknown');

export const SourcedStringSchema = z.object({
  value: z.string().default('unknown'),
  source: ValueSourceSchema,
});

export const SourcedNumOrStringSchema = z.object({
  value: z.union([z.number(), z.string()]).default('unknown'),
  source: ValueSourceSchema,
});

export const Box2DSchema = z.object({
  ymin: z.number().default(0),
  xmin: z.number().default(0),
  ymax: z.number().default(1000),
  xmax: z.number().default(1000),
});

export const VisualSpecSchema = z.object({
  frame: z.object({
    referenceWidth: z.number().default(1440),
    coordinateSystem: z.string().default('0-1000 normalized frame converted to 1440-wide reference frame'),
    conversionRule: z.string().default('Coordinates are a 0-1000 normalized frame converted to a 1440-wide reference frame'),
    detectedCrop: z.object({
      x: z.number(),
      y: z.number(),
      width: z.number(),
      height: z.number(),
    }).optional(),
  }),
  background: z.object({
    floor: SourcedStringSchema,
    lift: SourcedStringSchema.optional(),
    liftFadesAt: SourcedStringSchema.optional(),
    grain: SourcedStringSchema.default({ value: 'unknown', source: 'unknown' }),
    matteGloss: SourcedStringSchema.default({ value: 'unknown', source: 'unknown' }),
    uniform: z.boolean().default(true),
    noiseLevel: SourcedNumOrStringSchema.default({ value: 'unknown', source: 'unknown' }),
  }),
  paletteByRole: z.array(z.object({
    role: z.string().default('unknown'),
    name: z.string().default('unknown'),
    hex: SourcedStringSchema,
    token: z.string().default('--color-custom'),
    usage: z.string().default('unknown'),
  })).default([]),
  copyInventory: z.array(z.object({
    id: z.string().default('copy-1'),
    text: z.string().default('unknown'),
    location: z.string().default('unknown'),
    elementId: z.string().optional(),
    caseStyle: z.string().optional(),
    source: ValueSourceSchema,
  })).default([]),
  elementInventory: z.array(z.object({
    id: z.string().default('el-1'),
    kind: z.enum([
      'card', 'button', 'nav', 'text', 'badge', 'icon', 'image',
      'character', 'prop', 'input', 'container', 'other',
    ]).default('other'),
    label: z.string().default('unknown'),
    box: Box2DSchema,
    zOrder: z.object({ value: z.number().default(0), source: ValueSourceSchema }),
    parent: z.string().optional(),
    alignment: SourcedStringSchema.default({ value: 'unknown', source: 'unknown' }),
  })).default([]),
  typographyPerElement: z.array(z.object({
    id: z.string().default('type-1'),
    elementId: z.string().optional(),
    role: z.string().default('unknown'),
    sampleText: z.string().default('unknown'),
    fontCandidates: z.array(z.string()).default([]),
    freeFallback: z.string().default('unknown'),
    size: SourcedStringSchema,
    weight: SourcedNumOrStringSchema,
    lineHeight: SourcedStringSchema,
    letterSpacing: SourcedStringSchema,
    color: SourcedStringSchema,
  })).default([]),
  cardsContainers: z.array(z.object({
    id: z.string().default('card-1'),
    label: z.string().default('unknown'),
    elementId: z.string().optional(),
    box: Box2DSchema.optional(),
    radius: SourcedStringSchema,
    padding: SourcedStringSchema,
    gradientStops: z.array(SourcedStringSchema).default([]),
    gloss: SourcedStringSchema,
    shadow: SourcedStringSchema,
    rotation: SourcedStringSchema,
    overlap: SourcedStringSchema,
    crop: SourcedStringSchema,
  })).default([]),
  characters: z.array(z.object({
    id: z.string().default('char-1'),
    label: z.string().default('unknown'),
    description: z.string().default('unknown'),
    colors: z.array(SourcedStringSchema).default([]),
    materials: SourcedStringSchema,
    position: SourcedStringSchema,
    box: Box2DSchema.optional(),
    crop: SourcedStringSchema,
    assetPath: z.string().optional(),
  })).default([]),
  props: z.array(z.object({
    id: z.string().default('prop-1'),
    label: z.string().default('unknown'),
    description: z.string().default('unknown'),
    colors: z.array(SourcedStringSchema).default([]),
    materials: SourcedStringSchema,
    position: SourcedStringSchema,
    box: Box2DSchema.optional(),
    crop: SourcedStringSchema,
    assetPath: z.string().optional(),
  })).default([]),
  icons: z.array(z.object({
    id: z.string().default('icon-1'),
    label: z.string().default('unknown'),
    name: z.string().default('unknown'),
    description: z.string().default('unknown'),
    color: SourcedStringSchema,
    size: SourcedStringSchema,
    box: Box2DSchema.optional(),
    position: SourcedStringSchema,
    assetPath: z.string().optional(),
  })).default([]),
  shadowsAndShine: z.array(z.object({
    id: z.string().default('effect-1'),
    target: z.string().default('unknown'),
    type: z.enum(['shadow', 'shine', 'glow', 'inset']).default('shadow'),
    value: SourcedStringSchema,
    lightDirection: SourcedStringSchema,
  })).default([]),
  motion: z.array(z.object({
    element: z.string().default('unknown'),
    trigger: z.string().default('unknown'),
    description: z.string().default('unknown'),
    source: z.literal('inferred').default('inferred'),
  })).default([]),
  dosAndDonts: z.object({
    dos: z.array(z.string()).default([]),
    donts: z.array(z.string()).default([]),
  }).default({ dos: [], donts: [] }),
});

export const DesignSpecSchema = z.object({
  meta: z.object({
    title: z.string().max(60).default('unknown'),
    theme: z.string().default('unknown'),
    industry: z.string().default('unknown'),
    styleTags: z.array(z.string()).default([]),
    sections: z.array(z.string()).default([]),
    summary: z.string().default('unknown'),
    description: z.string().default('unknown'),
  }),
  colors: z.array(ColorTokenSchema).default([]),
  typography: z.object({
    primaryFont: TypefaceInfoSchema.default({
      name: 'unknown',
      substitute: 'unknown',
      role: 'unknown',
      weights: [],
      sizes: [],
      lineHeight: 'unknown',
      letterSpacing: 'unknown',
      token: '--font-unknown',
    }),
    secondaryFont: TypefaceInfoSchema.optional(),
    utilityFont: TypefaceInfoSchema.optional(),
    typeScale: z.array(TypeScaleItemSchema).default([]),
  }),
  spacing: z.object({
    baseUnit: z.number().default(4),
    density: z.string().default('unknown'),
    scale: z.array(SpacingItemSchema).default([]),
    radii: z.array(RadiusItemSchema).default([]),
    shadows: z.array(ElevationItemSchema).default([]),
    layout: z.object({
      pageMaxWidth: z.string().default('unknown'),
      sectionGap: z.string().default('unknown'),
      cardPadding: z.string().default('unknown'),
      elementGap: z.string().default('unknown'),
    }),
  }),
  surfaces: z.array(SurfaceItemSchema).default([]),
  components: z.array(ComponentSpecSchema).default([]),
  dosAndDonts: z.object({
    dos: z.array(z.string()).default([]),
    donts: z.array(z.string()).default([]),
  }),
  visualSpec: VisualSpecSchema.optional(),
});

export function normalizeDesignSpec(spec: DesignSpec): DesignSpec {
  spec.colors = spec.colors.map((c) => {
    let val = c.value?.trim() || 'unknown';
    if (val.startsWith('#')) {
      val = val.toUpperCase();
    }
    return { ...c, value: val };
  });

  spec.surfaces = spec.surfaces.map((s) => {
    let val = s.value?.trim() || 'unknown';
    if (val.startsWith('#')) {
      val = val.toUpperCase();
    }
    return { ...s, value: val };
  });

  if (spec.meta.title) {
    spec.meta.title = spec.meta.title.trim().slice(0, 60);
  }

  return spec;
}

/**
 * Strips fabrications: NEVER injects Inter, #000000, default tags, or fake summaries.
 * Missing values strictly become "unknown".
 */
export function sanitizeSpecData(data: any): any {
  if (!data || typeof data !== 'object') {
    data = {};
  }
  const obj = { ...data };

  // Ensure meta
  obj.meta = { ...obj.meta };
  obj.meta.title =
    typeof obj.meta.title === 'string' && obj.meta.title.trim()
      ? obj.meta.title.trim().slice(0, 60)
      : 'unknown';
  const rawTheme = String(obj.meta.theme || '').toLowerCase();
  obj.meta.theme = ['light', 'dark', 'mixed'].includes(rawTheme) ? rawTheme : (rawTheme || 'unknown');
  obj.meta.industry = typeof obj.meta.industry === 'string' && obj.meta.industry ? obj.meta.industry : 'unknown';
  obj.meta.styleTags = Array.isArray(obj.meta.styleTags) ? obj.meta.styleTags : [];
  obj.meta.sections = Array.isArray(obj.meta.sections) ? obj.meta.sections : [];
  obj.meta.summary = typeof obj.meta.summary === 'string' && obj.meta.summary ? obj.meta.summary : 'unknown';
  obj.meta.description = typeof obj.meta.description === 'string' && obj.meta.description ? obj.meta.description : 'unknown';

  // Ensure colors is array with no fake #000000
  if (!Array.isArray(obj.colors)) {
    obj.colors = [];
  } else {
    obj.colors = obj.colors.map((c: any, idx: number) => ({
      name: typeof c?.name === 'string' && c.name ? c.name : 'unknown',
      value: typeof c?.value === 'string' && c.value ? (c.value.startsWith('#') ? c.value.toUpperCase() : `#${c.value}`.toUpperCase()) : 'unknown',
      token: typeof c?.token === 'string' && c.token ? c.token : `--color-${idx + 1}`,
      role: typeof c?.role === 'string' && c.role ? c.role : 'unknown',
    }));
  }

  // Ensure typography with no fake Inter
  if (!obj.typography || typeof obj.typography !== 'object') {
    obj.typography = {
      primaryFont: {
        name: 'unknown',
        substitute: 'unknown',
        role: 'unknown',
        weights: [],
        sizes: [],
        lineHeight: 'unknown',
        letterSpacing: 'unknown',
        token: '--font-unknown',
      },
      typeScale: [],
    };
  } else {
    obj.typography = { ...obj.typography };
    if (!obj.typography.primaryFont || typeof obj.typography.primaryFont !== 'object') {
      obj.typography.primaryFont = {
        name: 'unknown',
        substitute: 'unknown',
        role: 'unknown',
        weights: [],
        sizes: [],
        lineHeight: 'unknown',
        letterSpacing: 'unknown',
        token: '--font-unknown',
      };
    } else {
      obj.typography.primaryFont = {
        name: typeof obj.typography.primaryFont.name === 'string' && obj.typography.primaryFont.name ? obj.typography.primaryFont.name : 'unknown',
        substitute: typeof obj.typography.primaryFont.substitute === 'string' ? obj.typography.primaryFont.substitute : 'unknown',
        role: typeof obj.typography.primaryFont.role === 'string' ? obj.typography.primaryFont.role : 'unknown',
        weights: Array.isArray(obj.typography.primaryFont.weights) ? obj.typography.primaryFont.weights : [],
        sizes: Array.isArray(obj.typography.primaryFont.sizes) ? obj.typography.primaryFont.sizes : [],
        lineHeight: typeof obj.typography.primaryFont.lineHeight === 'string' ? obj.typography.primaryFont.lineHeight : 'unknown',
        letterSpacing: typeof obj.typography.primaryFont.letterSpacing === 'string' ? obj.typography.primaryFont.letterSpacing : 'unknown',
        token: typeof obj.typography.primaryFont.token === 'string' ? obj.typography.primaryFont.token : '--font-primary',
      };
    }
    if (!Array.isArray(obj.typography.typeScale)) {
      obj.typography.typeScale = [];
    }
  }

  // Ensure spacing with no fake layout dimensions
  if (!obj.spacing || typeof obj.spacing !== 'object') {
    obj.spacing = {
      baseUnit: 4,
      density: 'unknown',
      scale: [],
      radii: [],
      shadows: [],
      layout: {
        pageMaxWidth: 'unknown',
        sectionGap: 'unknown',
        cardPadding: 'unknown',
        elementGap: 'unknown',
      },
    };
  } else {
    obj.spacing = { ...obj.spacing };
    obj.spacing.baseUnit = typeof obj.spacing.baseUnit === 'number' ? obj.spacing.baseUnit : 4;
    obj.spacing.density = typeof obj.spacing.density === 'string' ? obj.spacing.density : 'unknown';
    if (!Array.isArray(obj.spacing.scale)) obj.spacing.scale = [];
    if (!Array.isArray(obj.spacing.radii)) obj.spacing.radii = [];
    if (!Array.isArray(obj.spacing.shadows)) obj.spacing.shadows = [];
    if (!obj.spacing.layout || typeof obj.spacing.layout !== 'object') {
      obj.spacing.layout = {
        pageMaxWidth: 'unknown',
        sectionGap: 'unknown',
        cardPadding: 'unknown',
        elementGap: 'unknown',
      };
    } else {
      obj.spacing.layout = {
        pageMaxWidth: typeof obj.spacing.layout.pageMaxWidth === 'string' ? obj.spacing.layout.pageMaxWidth : 'unknown',
        sectionGap: typeof obj.spacing.layout.sectionGap === 'string' ? obj.spacing.layout.sectionGap : 'unknown',
        cardPadding: typeof obj.spacing.layout.cardPadding === 'string' ? obj.spacing.layout.cardPadding : 'unknown',
        elementGap: typeof obj.spacing.layout.elementGap === 'string' ? obj.spacing.layout.elementGap : 'unknown',
      };
    }
  }

  // Ensure surfaces is array
  if (!Array.isArray(obj.surfaces)) {
    obj.surfaces = [];
  }

  // Ensure components is array
  if (!Array.isArray(obj.components)) {
    obj.components = [];
  }

  // Ensure dosAndDonts
  if (!obj.dosAndDonts || typeof obj.dosAndDonts !== 'object') {
    obj.dosAndDonts = { dos: [], donts: [] };
  } else {
    obj.dosAndDonts = {
      dos: Array.isArray(obj.dosAndDonts.dos) ? obj.dosAndDonts.dos : [],
      donts: Array.isArray(obj.dosAndDonts.donts) ? obj.dosAndDonts.donts : [],
    };
  }

  return obj;
}

export function validateAnalyzeResult(data: any): {
  success: boolean;
  data?: AnalyzeResult;
  errors?: string[];
} {
  try {
    const parsed = AnalyzeResultSchema.parse(data);
    return { success: true, data: parsed };
  } catch (err: any) {
    if (err instanceof z.ZodError) {
      return {
        success: false,
        errors: err.issues.map((i) => `${i.path.join('.')}: ${i.message}`),
      };
    }
    return { success: false, errors: [String(err)] };
  }
}

export function validateDesignSpec(data: any): {
  success: boolean;
  data?: DesignSpec;
  errors?: string[];
} {
  try {
    const sanitized = sanitizeSpecData(data);
    const parsed = DesignSpecSchema.parse(sanitized);
    const normalized = normalizeDesignSpec(parsed);
    return { success: true, data: normalized };
  } catch (err: any) {
    if (err instanceof z.ZodError) {
      return {
        success: false,
        errors: err.issues.map((i) => `${i.path.join('.')}: ${i.message}`),
      };
    }
    return { success: false, errors: [String(err)] };
  }
}
