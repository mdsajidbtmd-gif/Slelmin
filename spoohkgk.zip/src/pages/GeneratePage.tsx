/**
 * S2 - S6 Generate Page
 * Upload, multi-site selection, processing, and rejection flows
 * Document 2, Section 4.2 - 4.5
 */
import React, { useEffect, useRef, useState, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { Upload, AlertCircle, ArrowLeft } from 'lucide-react';
import { useRunStore } from '../store/runStore';
import { Tile } from '../components/Tile';
import { SiteCard } from '../components/SiteCard';
import { StepList } from '../components/StepList';
import { MAX_FILES, MAX_FILE_MB } from '../config';

export const GeneratePage: React.FC = () => {
  const navigate = useNavigate();
  const fileInputRef = useRef<HTMLInputElement>(null);

  const {
    files,
    fileIssues,
    stepStatus,
    retryInfo,
    sites,
    phase,
    error,
    resultIds,
    elapsedSeconds,
    setFiles,
    reorderFiles,
    removeFile,
    clearFiles,
    startRun,
    cancelRun,
    resolveChoice,
    resetRun,
    incrementElapsed,
  } = useRunStore();

  const [thumbnails, setThumbnails] = useState<string[]>([]);
  const [selectedSiteId, setSelectedSiteId] = useState<string>('');
  const [isDragging, setIsDragging] = useState(false);

  // Generate local object URLs for thumbnail display
  useEffect(() => {
    const urls = files.map((file) => URL.createObjectURL(file));
    setThumbnails(urls);
    return () => {
      urls.forEach((url) => URL.revokeObjectURL(url));
    };
  }, [files]);

  // Set default selected site when entering 'choosing' phase
  useEffect(() => {
    if (phase === 'choosing' && sites.length > 0 && !selectedSiteId) {
      setSelectedSiteId(sites[0].id);
    }
  }, [phase, sites, selectedSiteId]);

  // Timer for elapsedSeconds during processing
  useEffect(() => {
    if (phase !== 'processing') return;
    const interval = setInterval(() => {
      incrementElapsed();
    }, 1000);
    return () => clearInterval(interval);
  }, [phase, incrementElapsed]);

  // Navigate to result when done
  useEffect(() => {
    if (phase === 'done' && resultIds.length > 0) {
      navigate(`/result/${resultIds[0]}`);
    }
  }, [phase, resultIds, navigate]);

  // Global paste handler (Ctrl+V) for uploading screenshots directly
  useEffect(() => {
    const handlePaste = (e: ClipboardEvent) => {
      const items = e.clipboardData?.items;
      if (!items) return;
      const pastedFiles: File[] = [];
      for (let i = 0; i < items.length; i++) {
        if (items[i].type.startsWith('image/')) {
          const file = items[i].getAsFile();
          if (file) pastedFiles.push(file);
        }
      }
      if (pastedFiles.length > 0) {
        handleFilesAdded(pastedFiles);
      }
    };
    window.addEventListener('paste', handlePaste);
    return () => window.removeEventListener('paste', handlePaste);
  }, [files]);

  const handleFilesAdded = useCallback(
    (newFilesList: FileList | File[]) => {
      const array = Array.from(newFilesList);
      const combined = [...files, ...array].slice(0, MAX_FILES);
      setFiles(combined);
    },
    [files, setFiles]
  );

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      handleFilesAdded(e.dataTransfer.files);
    }
  };

  // Drag and drop tile reordering handlers
  const [draggedTileIndex, setDraggedTileIndex] = useState<number | null>(null);

  const handleTileDragStart = (e: React.DragEvent, index: number) => {
    setDraggedTileIndex(index);
    e.dataTransfer.setData('text/plain', String(index));
  };

  const handleTileDragOver = (e: React.DragEvent, index: number) => {
    e.preventDefault();
  };

  const handleTileDrop = (e: React.DragEvent, targetIndex: number) => {
    e.preventDefault();
    if (draggedTileIndex !== null && draggedTileIndex !== targetIndex) {
      reorderFiles(draggedTileIndex, targetIndex);
    }
    setDraggedTileIndex(null);
  };

  // ------------------------------------------------------------------------
  // S5: Processing View
  // ------------------------------------------------------------------------
  if (phase === 'processing') {
    return (
      <div className="max-w-[1200px] mx-auto px-6 py-16 flex flex-col items-center justify-center">
        <StepList
          stepStatus={stepStatus}
          elapsedSeconds={elapsedSeconds}
          retryInfo={retryInfo}
          onCancel={cancelRun}
        />
      </div>
    );
  }

  // ------------------------------------------------------------------------
  // S4: Choose a site View (Multi-site detection)
  // ------------------------------------------------------------------------
  if (phase === 'choosing' && sites.length > 0) {
    return (
      <div className="max-w-[800px] mx-auto px-6 py-12 flex flex-col gap-8 text-left">
        <div>
          <h2 className="text-2xl font-normal text-white tracking-[-0.027em]">
            We found screenshots from more than one website.
          </h2>
          <p className="text-sm text-[#858585] mt-1">
            Which one should we extract first?
          </p>
        </div>

        <div className="flex flex-col gap-4">
          {sites.map((site) => (
            <SiteCard
              key={site.id}
              site={site}
              selected={selectedSiteId === site.id}
              onSelect={() => setSelectedSiteId(site.id)}
              thumbnails={thumbnails}
            />
          ))}
        </div>

        <div className="flex flex-wrap items-center gap-4 pt-4 border-t border-[rgba(255,255,255,0.08)]">
          <button
            type="button"
            data-testid="btn-extract-one"
            onClick={() => resolveChoice({ siteIds: [selectedSiteId || sites[0].id] })}
            className="bg-[#0063e1] hover:bg-[#0052be] text-white text-sm font-medium px-6 py-3 rounded-[59px] transition-colors cursor-pointer"
          >
            Extract this one
          </button>
          <button
            type="button"
            data-testid="btn-extract-all"
            onClick={() => resolveChoice({ siteIds: sites.map((s) => s.id) })}
            className="bg-[#0d0d0d] hover:bg-[#1f1f1f] text-white text-sm font-medium px-6 py-3 rounded-[59px] inset-border transition-colors cursor-pointer"
          >
            Extract all, one after another
          </button>
        </div>
      </div>
    );
  }

  // ------------------------------------------------------------------------
  // S6: Rejection / Send a better image View
  // ------------------------------------------------------------------------
  if (phase === 'rejected' && fileIssues.length > 0) {
    return (
      <div className="max-w-2xl mx-auto px-6 py-16 flex flex-col items-center gap-8 text-center">
        <div className="w-12 h-12 rounded-full bg-[#1f1f1f] text-white inset-border flex items-center justify-center">
          <AlertCircle className="w-6 h-6 text-white" />
        </div>

        <div className="flex flex-col gap-2">
          <h2 className="text-2xl font-normal text-white tracking-[-0.027em]">
            Please send a better image
          </h2>
          <p className="text-sm text-[#858585] max-w-md">
            We could not extract a precision design system from the uploaded files due to the reasons below.
          </p>
        </div>

        <div className="w-full bg-[#0d0d0d] rounded-[16px] inset-border p-4 flex flex-col gap-3 text-left">
          {fileIssues.map((issue, idx) => (
            <div
              key={idx}
              className="flex items-start gap-3 p-3 rounded-[8px] bg-[#040910] inset-border"
            >
              <div className="flex-1">
                <span className="text-xs font-mono text-white block mb-0.5">
                  {issue.fileName}
                </span>
                <span className="text-xs text-[#858585]">
                  {issue.reason || `Issue code: ${issue.code}`}
                </span>
              </div>
            </div>
          ))}
        </div>

        <button
          type="button"
          onClick={() => {
            clearFiles();
            resetRun();
          }}
          className="bg-[#0063e1] hover:bg-[#0052be] text-white text-sm font-medium px-8 py-3 rounded-[59px] transition-colors cursor-pointer"
        >
          Choose another image
        </button>
      </div>
    );
  }

  // ------------------------------------------------------------------------
  // General Error View
  // ------------------------------------------------------------------------
  if (phase === 'error' && error) {
    const isDebug = typeof window !== 'undefined' && new URLSearchParams(window.location.search).get('debug') === '1';

    return (
      <div className="max-w-xl mx-auto px-6 py-16 flex flex-col items-center gap-6 text-center">
        <div className="w-12 h-12 rounded-full bg-[#1f1f1f] inset-border flex items-center justify-center">
          <AlertCircle className="w-6 h-6 text-white" />
        </div>
        <div className="flex flex-col gap-2 w-full">
          <h2 className="text-xl font-normal text-white">Generation Failed</h2>
          <p className="text-sm text-[#858585] leading-relaxed">
            {error.message || 'An unexpected error occurred during analysis.'}
          </p>
          {isDebug && (
            <div className="mt-4 p-4 rounded-[12px] bg-[#0d0d0d] border border-red-900/60 text-left font-mono text-xs text-red-300 w-full overflow-x-auto flex flex-col gap-1.5">
              <div className="font-semibold text-red-400 mb-1 border-b border-red-900/40 pb-1">Debug Error Information (?debug=1)</div>
              <div><span className="text-[#858585]">Code:</span> {error.code || 'unknown'}</div>
              <div><span className="text-[#858585]">Message:</span> {error.message}</div>
              {(error as any).status && <div><span className="text-[#858585]">HTTP Status:</span> {(error as any).status}</div>}
              {(error as any).rawError && (
                <div className="mt-2 text-[11px] text-[#a0a0a0] whitespace-pre-wrap break-all bg-[#040910] p-2.5 rounded border border-[#1f1f1f]">
                  {(error as any).rawError}
                </div>
              )}
            </div>
          )}
        </div>
        <button
          type="button"
          onClick={resetRun}
          className="bg-[#0d0d0d] hover:bg-[#1f1f1f] text-white text-sm px-6 py-2.5 rounded-[59px] inset-border transition-colors cursor-pointer"
        >
          Try Again
        </button>
      </div>
    );
  }

  // ------------------------------------------------------------------------
  // S2 & S3: Upload Dropzone & Selected Files Grid
  // ------------------------------------------------------------------------
  return (
    <div className="max-w-[1200px] mx-auto px-6 py-12 flex flex-col gap-8 text-center">
      {/* Hidden File Input */}
      <input
        ref={fileInputRef}
        type="file"
        data-testid="file-input"
        multiple
        accept="image/png,image/jpeg,image/webp"
        className="hidden"
        onChange={(e) => {
          if (e.target.files) handleFilesAdded(e.target.files);
        }}
      />

      {/* Header text */}
      <div className="flex flex-col items-center gap-2 max-w-lg mx-auto">
        <h1 className="text-3xl font-normal text-white tracking-[-0.027em]">
          Generate design.md
        </h1>
        <p className="text-sm text-[#858585]">
          Upload screenshots you are happy to share.
        </p>
      </div>

      {/* Dropzone Area */}
      <div
        data-testid="dropzone"
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
        onClick={() => fileInputRef.current?.click()}
        className={`w-full max-w-3xl mx-auto rounded-[24px] p-12 transition-all cursor-pointer flex flex-col items-center justify-center gap-4 inset-border ${
          isDragging
            ? 'bg-[#1f1f1f] border-[#0063e1]'
            : 'bg-[#040910] hover:bg-[#0d0d0d]'
        }`}
      >
        <div className="w-12 h-12 rounded-full bg-[#0d0d0d] inset-border flex items-center justify-center text-[#858585]">
          <Upload className="w-5 h-5 text-white" />
        </div>

        <div className="flex flex-col gap-1">
          <p className="text-base font-normal text-white tracking-[-0.015em]">
            Drop website screenshots here, click to upload, or paste (Ctrl+V)
          </p>
          <p className="text-xs text-[#858585] font-mono">
            PNG, JPG or WEBP · up to {MAX_FILES} · {MAX_FILE_MB} MB each
          </p>
        </div>
      </div>

      {/* S3: Selected Files Tiles */}
      {files.length > 0 && (
        <div className="w-full max-w-4xl mx-auto flex flex-col gap-6 mt-4">
          <div className="flex items-center justify-between border-b border-[rgba(255,255,255,0.08)] pb-3 text-left">
            <span className="text-sm font-medium text-white">
              {files.length} screenshot{files.length > 1 ? 's' : ''} added
            </span>
            <span className="text-xs text-[#858585]">
              Order matters: top of the page first.
            </span>
          </div>

          {/* Tiles Grid */}
          <div className="flex flex-wrap gap-4 justify-start">
            {files.map((file, idx) => (
              <Tile
                key={`${file.name}-${idx}`}
                index={idx}
                file={file}
                thumbUrl={thumbnails[idx] || ''}
                isFirst={idx === 0}
                isLast={idx === files.length - 1}
                onRemove={removeFile}
                onMoveEarlier={(i) => reorderFiles(i, i - 1)}
                onMoveLater={(i) => reorderFiles(i, i + 1)}
                onDragStart={handleTileDragStart}
                onDragOver={handleTileDragOver}
                onDrop={handleTileDrop}
              />
            ))}
          </div>

          {/* Action Buttons */}
          <div className="flex items-center gap-4 pt-4">
            <button
              type="button"
              data-testid="btn-generate"
              onClick={startRun}
              className="bg-[#0063e1] hover:bg-[#0052be] text-white text-sm font-medium px-8 py-3.5 rounded-[59px] transition-colors cursor-pointer"
            >
              Generate design.md
            </button>
            <button
              type="button"
              data-testid="btn-clear"
              onClick={clearFiles}
              className="text-sm text-[#858585] hover:text-white transition-colors cursor-pointer"
            >
              Clear all
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
