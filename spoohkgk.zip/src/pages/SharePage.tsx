/**
 * S10 Public Share View
 * Document 2, Section 4.9 & 5.11
 */
import React, { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { Copy, Download, FileText, Sparkles, Loader2, ArrowLeft } from 'lucide-react';
import { getShare, incrementCopy } from '../storage/remote';
import { ShareDoc, ShareImageDoc } from '../types';
import { MarkdownView } from '../components/MarkdownView';
import { RawView } from '../components/RawView';
import { Lightbox } from '../components/Lightbox';
import { TagChip } from '../components/TagChip';
import { useToast } from '../components/Toast';

export const SharePage: React.FC = () => {
  const { shareId } = useParams<{ shareId: string }>();
  const { showToast } = useToast();

  const [doc, setDoc] = useState<ShareDoc | null>(null);
  const [images, setImages] = useState<ShareImageDoc[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<'preview' | 'raw'>('preview');
  const [lightboxIndex, setLightboxIndex] = useState<number | null>(null);

  useEffect(() => {
    let mounted = true;
    async function load() {
      if (!shareId) return;
      setLoading(true);
      try {
        const data = await getShare(shareId);
        if (mounted) {
          if (data) {
            setDoc(data.doc);
            setImages(data.images);
          }
          setLoading(false);
        }
      } catch (err) {
        if (mounted) setLoading(false);
      }
    }
    load();
    return () => {
      mounted = false;
    };
  }, [shareId]);

  const handleCopy = async () => {
    if (!doc) return;
    try {
      await navigator.clipboard.writeText(doc.markdown);
      showToast('Copied design.md to clipboard');
      if (shareId) {
        incrementCopy(shareId).catch(() => {});
      }
    } catch {
      showToast('Failed to copy to clipboard');
    }
  };

  const handleDownload = () => {
    if (!doc) return;
    const blob = new Blob([doc.markdown], { type: 'text/markdown;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'design.md';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    showToast('Downloaded design.md');
  };

  const handlePrint = () => {
    setActiveTab('preview');
    setTimeout(() => {
      window.print();
    }, 150);
  };

  if (loading) {
    return (
      <div className="max-w-[1200px] mx-auto px-6 py-24 flex items-center justify-center">
        <div className="flex flex-col items-center gap-4 text-[#858585]">
          <Loader2 className="w-8 h-8 animate-spin text-[#0063e1]" />
          <p className="text-sm">Loading shared specification...</p>
        </div>
      </div>
    );
  }

  if (!doc) {
    return (
      <div className="max-w-[800px] mx-auto px-6 py-24 text-center flex flex-col items-center gap-6">
        <h1 className="text-3xl font-medium text-white">Share Not Found</h1>
        <p className="text-sm text-[#858585]">
          This link may have expired, or the author has unpublished it.
        </p>
        <Link
          to="/library"
          className="inline-flex items-center gap-2 bg-[#0063e1] text-white px-5 py-2.5 rounded-full text-sm font-medium hover:bg-[#0051b8] transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          Browse Public Library
        </Link>
      </div>
    );
  }

  const allTags = [
    ...(doc.tags?.industry || []),
    ...(doc.tags?.style || []),
    ...(doc.tags?.sections || []),
  ];

  return (
    <div className="max-w-[1440px] mx-auto px-6 py-8 flex flex-col gap-6 text-left w-full">
      {/* Top bar with back and actions */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-[#1f1f1f] pb-6">
        <div className="flex flex-col gap-2">
          <div className="flex items-center gap-2">
            <span className="text-xs uppercase tracking-wider text-[#0063e1] font-semibold">
              Shared with Loupe
            </span>
          </div>
          <h1
            data-testid="share-title"
            className="text-2xl md:text-3xl font-semibold text-white tracking-tight"
          >
            {doc.title}
          </h1>
          {allTags.length > 0 && (
            <div className="flex flex-wrap gap-1.5 mt-1">
              {allTags.map((tag) => (
                <TagChip key={tag} label={tag} active={false} />
              ))}
            </div>
          )}
        </div>

        {/* Action buttons */}
        <div className="flex flex-wrap items-center gap-2.5">
          <button
            onClick={handleCopy}
            className="inline-flex items-center gap-2 bg-[#1f1f1f] hover:bg-[#2b2c2e] text-white px-4 py-2 rounded-full text-xs font-medium transition-colors"
          >
            <Copy className="w-3.5 h-3.5" />
            Copy .md
          </button>
          <button
            onClick={handleDownload}
            className="inline-flex items-center gap-2 bg-[#1f1f1f] hover:bg-[#2b2c2e] text-white px-4 py-2 rounded-full text-xs font-medium transition-colors"
          >
            <Download className="w-3.5 h-3.5" />
            Download
          </button>
          <button
            onClick={handlePrint}
            className="inline-flex items-center gap-2 bg-[#1f1f1f] hover:bg-[#2b2c2e] text-white px-4 py-2 rounded-full text-xs font-medium transition-colors"
          >
            <FileText className="w-3.5 h-3.5" />
            PDF
          </button>
          <Link
            to="/generate"
            data-testid="btn-create-own"
            className="inline-flex items-center gap-2 bg-[#0063e1] hover:bg-[#0051b8] text-white px-4 py-2 rounded-full text-xs font-medium transition-colors"
          >
            <Sparkles className="w-3.5 h-3.5" />
            Create Your Own
          </Link>
        </div>
      </div>

      {/* Main split grid: screenshots on left, markdown on right */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Left Column: Source Screenshots */}
        <div className="lg:col-span-4 flex flex-col gap-4">
          <h2 className="text-xs uppercase tracking-wider text-[#858585] font-medium">
            Source Screenshots ({images.length})
          </h2>
          <div className="flex flex-col gap-3">
            {images.map((img, idx) => (
              <div
                key={idx}
                data-testid={`share-image-${idx}`}
                onClick={() => setLightboxIndex(idx)}
                className="bg-[#040910] border border-[#1f1f1f] rounded-[12px] overflow-hidden cursor-pointer group hover:border-[#0063e1] transition-colors"
              >
                <img
                  src={img.dataUrl}
                  alt={`Screenshot ${idx + 1}`}
                  className="w-full h-auto max-h-[300px] object-cover object-top group-hover:scale-101 transition-transform"
                />
              </div>
            ))}
          </div>
        </div>

        {/* Right Column: Markdown Spec View */}
        <div className="lg:col-span-8 flex flex-col gap-4">
          {/* Tabs */}
          <div className="flex items-center justify-between border-b border-[#1f1f1f] pb-3">
            <div className="flex items-center gap-2">
              <button
                onClick={() => setActiveTab('preview')}
                className={`px-4 py-1.5 rounded-full text-xs font-medium transition-colors ${
                  activeTab === 'preview'
                    ? 'bg-[#0063e1] text-white'
                    : 'text-[#858585] hover:text-white'
                }`}
              >
                Preview
              </button>
              <button
                onClick={() => setActiveTab('raw')}
                className={`px-4 py-1.5 rounded-full text-xs font-medium transition-colors ${
                  activeTab === 'raw'
                    ? 'bg-[#0063e1] text-white'
                    : 'text-[#858585] hover:text-white'
                }`}
              >
                Raw .md
              </button>
            </div>
          </div>

          {/* Tab content */}
          <div className="bg-[#0a0a0a] border border-[#1f1f1f] rounded-[16px] p-6 overflow-hidden">
            {activeTab === 'preview' ? (
              <MarkdownView content={doc.markdown} />
            ) : (
              <RawView content={doc.markdown} />
            )}
          </div>
        </div>
      </div>

      {/* Lightbox Modal */}
      {lightboxIndex !== null && (
        <Lightbox
          images={images.map((img) => ({ dataUrl: img.dataUrl, name: `Screenshot ${img.index + 1}` }))}
          currentIndex={lightboxIndex}
          isOpen={lightboxIndex !== null}
          onClose={() => setLightboxIndex(null)}
          onPrev={() =>
            setLightboxIndex((prev) =>
              prev === null ? 0 : (prev - 1 + images.length) % images.length
            )
          }
          onNext={() =>
            setLightboxIndex((prev) =>
              prev === null ? 0 : (prev + 1) % images.length
            )
          }
        />
      )}
    </div>
  );
};
