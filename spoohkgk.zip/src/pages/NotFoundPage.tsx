/**
 * S12 Not Found Page
 * Document 2, Section 4.10
 */
import React from 'react';
import { Link } from 'react-router-dom';

export const NotFoundPage: React.FC = () => {
  return (
    <div className="max-w-md mx-auto px-6 py-24 text-center flex flex-col items-center gap-6">
      <h1 className="text-2xl font-normal text-white tracking-[-0.027em]">
        This page is not available.
      </h1>
      <Link
        to="/"
        className="bg-[#0063e1] hover:bg-[#0052be] text-white text-sm font-medium px-6 py-2.5 rounded-[59px] transition-colors"
      >
        Go home
      </Link>
    </div>
  );
};
