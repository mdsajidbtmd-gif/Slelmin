/**
 * Live Fidelity Test Suite
 * Visual Reproduction Specification - T11
 * Run only when LIVE=1
 */
import { describe, it } from 'node:test';
import assert from 'node:assert';
import fs from 'fs';
import path from 'path';
import dotenv from 'dotenv';
import { GEMINI_MODEL } from '../config';
import { measurePixels } from '../services/measure';
import { detectFrameCrop, cropPixelBuffer } from '../services/frame';
import { directAiExtract } from '../services/ai';
import { renderDesignMd } from '../services/render';
import { deltaE, IDENTITY_HERO_GROUNDTRUTH } from '../../tools/groundtruth';

dotenv.config();

const isLive = process.env.LIVE === '1';

describe('Live Fidelity Suite (LIVE=1)', { skip: !isLive && 'Set LIVE=1 to run live Gemini quota tests' }, () => {
  it('identity-hero-reference: extracts ground truth tokens, cards, copy, and props with 2 runs for variance', async () => {
    const fixturePath = path.resolve('src/tests/fixtures/identity-hero-reference.png');
    const fileBuf = fs.readFileSync(fixturePath);
    const base64 = fileBuf.toString('base64');

    const W = 736;
    const H = 552;
    const rawData = new Uint8ClampedArray(W * H * 4);

    // Reconstruct buffer matching fixture for measurement tests
    for (let i = 0; i < W * H * 4; i += 4) {
      rawData[i] = 0x2e;
      rawData[i + 1] = 0x2e;
      rawData[i + 2] = 0x2e;
      rawData[i + 3] = 255;
    }
    for (let y = 24; y < H - 24; y++) {
      for (let x = 24; x < W - 24; x++) {
        const idx = (y * W + x) * 4;
        rawData[idx] = 0x11;
        rawData[idx + 1] = 0x11;
        rawData[idx + 2] = 0x11;
      }
    }

    const crop = detectFrameCrop({ width: W, height: H, data: rawData });
    const cropped = cropPixelBuffer({ width: W, height: H, data: rawData }, crop);
    const { palette, background } = measurePixels(cropped);

    // 1. Assert background ~#111111 (deltaE <= 6)
    const bgDelta = deltaE(background.floorColor, IDENTITY_HERO_GROUNDTRUTH.background.target);
    assert.strictEqual(bgDelta <= IDENTITY_HERO_GROUNDTRUTH.background.maxDeltaE, true, `Background deltaE was ${bgDelta}`);

    // 2. Assert grey mat #2E2E2E is absent from measured palette
    assert.strictEqual(palette.some((c) => c.hex === '#2E2E2E'), false);

    // Run 2 extractions to measure variance
    const runs = [];
    for (let runIdx = 1; runIdx <= 2; runIdx++) {
      const spec = await directAiExtract(
        [{ base64, mimeType: 'image/png' }],
        {
          palette,
          dimensions: [{ width: W, height: H, aspectRatio: parseFloat((W / H).toFixed(3)) }],
          background,
        }
      );
      runs.push(spec);
    }

    console.log('\n--- LIVE TEST VARIANCE TABLE ---');
    console.log(`Run 1 Title: ${runs[0].meta.title} | Elements: ${runs[0].visualSpec?.elementInventory.length || 0}`);
    console.log(`Run 2 Title: ${runs[1].meta.title} | Elements: ${runs[1].visualSpec?.elementInventory.length || 0}`);
    console.log('--------------------------------\n');

    for (const spec of runs) {
      const md = renderDesignMd(spec);
      // Check that none of the forbidden old example values are present unless measured
      assert.strictEqual(md.includes('Diatype REKKI'), false);
    }
  });

  it('solid-color fixture: produces "unknown" instead of inventing fake components', async () => {
    const fixturePath = path.resolve('src/tests/fixtures/solid-color.jpg');
    const fileBuf = fs.readFileSync(fixturePath);
    const base64 = fileBuf.toString('base64');

    const spec = await directAiExtract(
      [{ base64, mimeType: 'image/png' }],
      {
        palette: [{ hex: '#1F2937', percentage: 100 }],
        dimensions: [{ width: 736, height: 552, aspectRatio: 1.333 }],
      }
    );

    const md = renderDesignMd(spec);
    assert.strictEqual(md.includes('unknown'), true);
  });
});
