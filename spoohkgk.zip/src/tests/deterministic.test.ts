/**
 * Deterministic (no network) test suite for Loupe v2.0.0
 * Document 2, Section 5.1 & Visual Reproduction Specification Tests
 */
import { describe, it } from 'node:test';
import assert from 'node:assert';
import { measurePixels } from '../services/measure';
import { detectFrameCrop, cropPixelBuffer } from '../services/frame';
import { sanitizeSpecData, validateDesignSpec } from '../services/validate';
import { renderDesignMd } from '../services/render';
import { DesignSpec } from '../types';

describe('Deterministic Accuracy Tests', () => {
  it('Flat #111111 returns exactly #111111', () => {
    const width = 100;
    const height = 100;
    const data = new Uint8ClampedArray(width * height * 4);

    for (let i = 0; i < width * height; i++) {
      const idx = i * 4;
      data[idx] = 17; // 0x11
      data[idx + 1] = 17; // 0x11
      data[idx + 2] = 17; // 0x11
      data[idx + 3] = 255;
    }

    const { palette, background } = measurePixels({ width, height, data });
    assert.strictEqual(palette.length > 0, true);
    assert.strictEqual(palette[0].hex, '#111111');
    assert.strictEqual(background.floorColor, '#111111');
  });

  it('A 2% lime square on black appears in the palette', () => {
    const width = 100;
    const height = 100;
    const data = new Uint8ClampedArray(width * height * 4);

    // Fill with black #000000
    for (let i = 0; i < width * height; i++) {
      const idx = i * 4;
      data[idx] = 0;
      data[idx + 1] = 0;
      data[idx + 2] = 0;
      data[idx + 3] = 255;
    }

    // Draw 2% lime square #F2FC4E (200 pixels: 14x14 = 196 ~ 2%)
    for (let y = 40; y < 54; y++) {
      for (let x = 40; x < 54; x++) {
        const idx = (y * width + x) * 4;
        data[idx] = 0xf2; // 242
        data[idx + 1] = 0xfc; // 252
        data[idx + 2] = 0x4e; // 78
        data[idx + 3] = 255;
      }
    }

    const { palette } = measurePixels({ width, height, data });
    const hasLime = palette.some((c) => c.hex === '#F2FC4E');
    assert.strictEqual(hasLime, true, `Lime #F2FC4E should appear in palette, got: ${palette.map((c) => c.hex).join(', ')}`);
  });

  it('A grey border is cropped and never appears in the palette', () => {
    const width = 200;
    const height = 200;
    const data = new Uint8ClampedArray(width * height * 4);

    // Fill entirely with grey mat #808080 (128, 128, 128)
    for (let i = 0; i < width * height; i++) {
      const idx = i * 4;
      data[idx] = 128;
      data[idx + 1] = 128;
      data[idx + 2] = 128;
      data[idx + 3] = 255;
    }

    // Inner design area: 20px padding -> [20, 20, 160, 160] filled with #0A0A0A and some blue #0063E1
    for (let y = 20; y < 180; y++) {
      for (let x = 20; x < 180; x++) {
        const idx = (y * width + x) * 4;
        data[idx] = 10;
        data[idx + 1] = 10;
        data[idx + 2] = 10;
        data[idx + 3] = 255;
      }
    }

    const cropResult = detectFrameCrop({ width, height, data });
    assert.strictEqual(cropResult.hasBorder, true);
    assert.strictEqual(cropResult.x, 20);
    assert.strictEqual(cropResult.y, 20);
    assert.strictEqual(cropResult.width, 160);
    assert.strictEqual(cropResult.height, 160);

    const croppedBuffer = cropPixelBuffer({ width, height, data }, cropResult);
    const { palette } = measurePixels(croppedBuffer);

    const hasGreyMat = palette.some((c) => c.hex === '#808080');
    assert.strictEqual(hasGreyMat, false, `Grey presentation mat should not be in cropped palette: ${palette.map((c) => c.hex).join(', ')}`);
  });

  it('sanitize/validate never inject Inter, #000000 or default tags', () => {
    const emptySpec = {};
    const sanitized = sanitizeSpecData(emptySpec);

    assert.notStrictEqual(sanitized.typography.primaryFont.name, 'Inter');
    assert.strictEqual(sanitized.typography.primaryFont.name, 'unknown');
    assert.strictEqual(sanitized.meta.title, 'unknown');
    assert.strictEqual(sanitized.meta.summary, 'unknown');
    assert.strictEqual(sanitized.meta.description, 'unknown');
    assert.deepStrictEqual(sanitized.meta.styleTags, []);
    assert.deepStrictEqual(sanitized.meta.sections, []);
    assert.strictEqual(sanitized.colors.length, 0);

    const validated = validateDesignSpec(emptySpec);
    assert.strictEqual(validated.success, true);
    assert.notStrictEqual(validated.data?.typography.primaryFont.name, 'Inter');
    assert.strictEqual(validated.data?.typography.primaryFont.name, 'unknown');
    assert.deepStrictEqual(validated.data?.meta.styleTags, []);
    assert.deepStrictEqual(validated.data?.meta.sections, []);
  });

  it('render snapshot prints "unknown" for missing fields', () => {
    const rawEmpty = sanitizeSpecData({});
    const validated = validateDesignSpec(rawEmpty);
    assert.strictEqual(validated.success, true);

    const md = renderDesignMd(validated.data!);
    assert.strictEqual(md.includes('unknown'), true);
    assert.strictEqual(md.includes('Inter'), false);
    assert.strictEqual(md.includes('Measured values are sampled from pixels; estimated and inferred values are labeled.'), true);
  });

  it('old-format results without visualSpec still render cleanly', () => {
    const oldSpec: DesignSpec = {
      meta: {
        title: 'Legacy Design System',
        theme: 'dark',
        industry: 'saas',
        styleTags: ['clean'],
        sections: ['hero'],
        summary: 'Legacy summary',
        description: 'Legacy description',
      },
      colors: [
        { name: 'Obsidian', value: '#101010', token: '--color-bg', role: 'Canvas floor' },
        { name: 'Accent', value: '#4F46E5', token: '--color-primary', role: 'CTA' },
      ],
      typography: {
        primaryFont: {
          name: 'Geist Sans',
          substitute: 'system-ui',
          role: 'Display',
          weights: [400, 600],
          sizes: ['16px', '32px'],
          lineHeight: '1.4',
          letterSpacing: '-0.02em',
          token: '--font-primary',
        },
        typeScale: [],
      },
      spacing: {
        baseUnit: 4,
        density: 'comfortable',
        scale: [],
        radii: [],
        shadows: [],
        layout: {
          pageMaxWidth: '1200px',
          sectionGap: '64px',
          cardPadding: '24px',
          elementGap: '16px',
        },
      },
      surfaces: [],
      components: [],
      dosAndDonts: {
        dos: ['Keep contrast high'],
        donts: ['Do not clutter'],
      },
    };

    const md = renderDesignMd(oldSpec);
    assert.strictEqual(md.includes('# Legacy Design System — Style Reference'), true);
    assert.strictEqual(md.includes('## Tokens — Colors'), true);
    assert.strictEqual(md.includes('Geist Sans'), true);
    assert.strictEqual(md.includes('`#4F46E5`'), true);
  });
});
