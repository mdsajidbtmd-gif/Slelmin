/**
 * Configuration and constants for Loupe v2.0.0
 * Document 2, Section 5.3 & Visual Reproduction Spec
 */

export const APP_NAME = 'Loupe';
export const TAGLINE = 'See the design. Rebuild it exactly.';
export const PIPELINE_VERSION = '2.0.0';

// Gemini model id - primary and fallbacks (pinned ids only, never "latest")
export const GEMINI_MODEL = (typeof process !== 'undefined' && process.env?.GEMINI_EXTRACT_MODEL) || 'gemini-3-flash-preview';
export const GEMINI_ANALYZE_MODEL = (typeof process !== 'undefined' && process.env?.GEMINI_ANALYZE_MODEL) || 'gemini-3-flash-preview';
export const GEMINI_LOCATE_MODEL = (typeof process !== 'undefined' && process.env?.GEMINI_LOCATE_MODEL) || 'gemini-3-flash-preview';
export const GEMINI_FALLBACK_MODELS = ['gemini-3.5-flash', 'gemini-3.8-flash', 'gemini-3.1-flash-lite'];

export const GEN_CONFIG = {
  maxOutputTokens: 32000,
  thinkingConfig: {
    thinkingBudget: 2048,
  },
};

export const EXTRACT_GEN_CONFIG = {
  maxOutputTokens: 32000,
  thinkingConfig: {
    thinkingBudget: 2048,
  },
};

export const MAX_FILES = 8;
export const MAX_FILE_MB = 10;
export const MIN_WIDTH = 200;
export const MIN_HEIGHT = 150;
export const MAX_DIM = 12000;
export const BLUR_THRESHOLD = 0.5;
export const MAX_SEGMENTS = 8;
export const SEGMENT_RATIO = 1.25;
export const TALL_RATIO = 2.2;
export const AI_MAX_SIDE = 1600;
export const AI_JPEG_QUALITY = 0.92;
export const RETRY_DELAYS_MS = [3000, 10000, 20000];
export const CALL_TIMEOUT_MS = 180000;
export const SCHEMA_RETRIES = 2;
export const COLOR_SNAP_DISTANCE = 40;
export const COLOR_MERGE_DISTANCE = 24;
export const HISTORY_MAX = 50;
export const SHARE_IMAGE_MAX_BYTES = 600000;
export const COVER_WIDTH = 480;
export const COVER_MAX_BYTES = 50000;
export const LIBRARY_FIRST_PAGE = 48;
export const LIBRARY_PAGE = 24;
export const AUTH_ENABLED = false;
export const PAYMENTS_ENABLED = false;

// Standard controlled vocabularies for tagging
export const INDUSTRY_TAGS = [
  'ai-tech',
  'saas',
  'fintech',
  'agency',
  'e-commerce',
  'developer-tools',
  'portfolio',
  'crypto-web3',
  'health-wellness',
  'media-editorial',
] as const;

export const STYLE_TAGS = [
  'dark',
  'light',
  'minimal',
  'enterprise',
  'retro-cyber',
  'playful',
  'monochrome',
  'brutalist',
  'high-contrast',
] as const;

export const SECTION_TAGS = [
  'hero',
  'pricing',
  'features',
  'faq',
  'testimonials',
  'navigation',
  'footer',
  'cta',
  'dashboard',
  'form',
] as const;

export const ANALYZE_PROMPT = `You are Loupe's screenshot inspection engine.
Analyze the provided website or application interface screenshot(s) carefully.

TASK:
1. Verify if the provided images are legitimate screenshots of a website, web application, dashboard, landing page, mobile web view, UI component, or digital interface design.
   - Set isWebsite to true for ANY digital website, web app, dashboard, mobile UI, or design mockup.
   - ONLY set isWebsite to false if the image is NOT a digital user interface at all (e.g. photos of real animals, nature, people, physical objects, non-UI artwork, or memes) or contains adult/unsafe material.
2. Determine if the screenshots belong to ONE website or MULTIPLE different websites.
3. Group the screenshots by website. For each website group:
   - id: a unique short slug (e.g. "site-1", "site-2")
   - label: concise descriptive label in the format "<Brand/Site name>: <Type of site>" (if unknown, use "unknown: <Type of site>")
   - description: 1 short sentence summarizing what the site is (if unknown, use "unknown")
   - sections: array of detected section types observed in the image (e.g. ["hero", "features"])
   - imageIndices: array of 0-based indices corresponding to the input images belonging to this site

REJECTION CODES (ONLY USE IF NOT A DIGITAL UI/WEBSITE):
- 'not_website': image is completely unrelated to websites/apps (e.g. photo of an animal, landscape, real-world object)
- 'adult_or_unsafe': contains adult, NSFW, or unsafe content
- 'unreadable': image is completely corrupted or pitch black

Return ONLY valid JSON matching this schema:
{
  "isWebsite": boolean,
  "rejectionCode": string | null,
  "rejectionReason": string | null,
  "sites": [
    {
      "id": string,
      "label": string,
      "description": string,
      "sections": string[],
      "imageIndices": number[]
    }
  ]
}`;

export const EXTRACT_PROMPT = `You are Loupe's pixel-accurate visual reproduction inspection engine.
Your task is to inspect the provided screenshot(s) and measured pixel data to generate an exhaustive, mathematically precise visual reproduction specification into structured JSON.

CRITICAL INVARIANTS AND RULES:
1. NEVER COPY EXAMPLES: Do not copy any placeholder values, colors, font names, or dimensions from this prompt. Every value in your output must come directly from observing the provided screenshot(s) and MEASURED pixel data.
2. UNKNOWN BEATS GUESSING: If a field or detail is not clearly visible, obscured, or absent in the image, output "unknown". NEVER guess, hallucinate, or inject default fonts (like Inter or Arial) or default colors (like #000000 or #FFFFFF) unless directly observed in the screenshot.
3. VERBATIM COPY INVENTORY: Transcribe every single visible piece of text exactly as rendered: exact casing (e.g. ALL CAPS, lowercase, Title Case), exact punctuation, dashes, icons, and partly hidden words. Include every heading, paragraph, button label, badge, navigation link, card title, metadata tag, and author/user name.
4. ELEMENT & REGION INVENTORY: Enumerate every visible UI component, container, card, badge, button, pill, input, character, and prop. Provide its bounding box in normalized [ymin, xmin, ymax, xmax] coordinates from 0 to 1000.
5. CHARACTERS, PROPS, & ICONS:
   - For every character/mascot/illustration: exhaustively describe what it is, its pose, what it wears, what it holds, facial expression, dominant colors, texture/materials, exact position, and whether it is cropped.
   - For every 3D prop/object/shape: describe the geometry, material (matte, glass, glossy, metallic), surface finish, lighting highlight direction, colors, position, and crop.
   - For every icon: specify its name/shape, stroke width, fill, color, and bounding box.
6. SOURCE TAGGING: Every color, dimension, radius, shadow, and position must carry a source tag:
   - "measured": strictly derived from the MEASURED PALETTE / MEASURED REGIONS pixel data.
   - "estimated": precisely visually estimated from the screenshot pixels.
   - "inferred": reasonably deduced from visual context (e.g., implied hover state, interaction physics).
   - "unknown": detail cannot be determined from the screenshot.
7. REFERENCE FRAME CONVERSION: Normalized coordinates are on a 0-1000 scale. They map to a 1440px wide reference desktop canvas (or native mobile width if mobile screenshot).
8. JSON ONLY: Output purely valid JSON conforming to the schema below without commentary or wrapping text outside the JSON.

SCHEMA:
{
  "meta": {
    "title": "<observed site/brand name or 'unknown'>",
    "theme": "dark" | "light" | "mixed",
    "industry": "<observed industry or 'unknown'>",
    "styleTags": ["<observed aesthetic tag 1>", "<tag 2>"],
    "sections": ["<observed section 1>", "<section 2>"],
    "summary": "<1-2 sentences high-level visual description or 'unknown'>",
    "description": "<2-4 sentences architectural breakdown of visual system or 'unknown'>"
  },
  "colors": [
    {
      "name": "<descriptive color name>",
      "value": "<observed uppercase hex>",
      "token": "<semantic token name like --color-primary>",
      "role": "<functional role in interface>"
    }
  ],
  "typography": {
    "primaryFont": {
      "name": "<observed primary typeface family or 'unknown'>",
      "substitute": "<recommended web-safe/open-source alternative or 'unknown'>",
      "role": "<primary typeface role or 'unknown'>",
      "weights": ["<observed numeric weights like 400, 600, 700>"],
      "sizes": ["<observed font sizes in px>"],
      "lineHeight": "<observed line-height ratio or 'unknown'>",
      "letterSpacing": "<observed letter spacing or 'unknown'>",
      "token": "<token name like --font-primary>"
    },
    "secondaryFont": {
      "name": "<observed secondary typeface or 'unknown'>",
      "substitute": "<substitute or 'unknown'>",
      "role": "<role or 'unknown'>",
      "weights": ["<weights>"],
      "sizes": ["<sizes>"],
      "lineHeight": "<line-height>",
      "letterSpacing": "<letter-spacing>",
      "token": "<token name>"
    },
    "utilityFont": {
      "name": "<observed mono/utility typeface or 'unknown'>",
      "substitute": "<substitute or 'unknown'>",
      "role": "<role or 'unknown'>",
      "weights": ["<weights>"],
      "sizes": ["<sizes>"],
      "lineHeight": "<line-height>",
      "letterSpacing": "<letter-spacing>",
      "token": "<token name>"
    },
    "typeScale": [
      {
        "role": "<text role e.g. hero-title, section-title, card-header, body, badge>",
        "family": "<font family>",
        "weight": "<numeric weight>",
        "size": "<size in px>",
        "lineHeight": "<line-height>",
        "letterSpacing": "<letter-spacing>",
        "token": "<token name>"
      }
    ]
  },
  "spacing": {
    "baseUnit": <observed base grid unit e.g. 4 or 8>,
    "density": "<comfortable | compact | spacious | unknown>",
    "scale": [
      { "name": "<scale name>", "value": "<size in px>", "token": "<token name>" }
    ],
    "radii": [
      { "element": "<target UI element>", "value": "<radius in px or pill>", "token": "<token name>" }
    ],
    "shadows": [
      { "name": "<shadow name>", "value": "<CSS shadow value>", "token": "<token name>" }
    ],
    "layout": {
      "pageMaxWidth": "<max width or 'unknown'>",
      "sectionGap": "<gap in px or 'unknown'>",
      "cardPadding": "<padding in px or 'unknown'>",
      "elementGap": "<gap in px or 'unknown'>"
    }
  },
  "surfaces": [
    {
      "level": <elevation number 0, 1, 2...>,
      "name": "<surface name>",
      "value": "<observed hex value>",
      "purpose": "<canvas floor, card surface, input, modal>"
    }
  ],
  "components": [
    {
      "name": "<component name>",
      "role": "<component purpose>",
      "description": "<structural and styling description>",
      "props": { "<prop key>": "<prop value>" },
      "tokensUsed": ["<token 1>", "<token 2>"]
    }
  ],
  "visualSpec": {
    "frame": {
      "referenceWidth": 1440,
      "coordinateSystem": "0-1000 normalized frame converted to 1440 reference width",
      "conversionRule": "Reference coordinate X = round(normalized_xmin * 1440 / 1000), width = round((normalized_xmax - normalized_xmin) * 1440 / 1000)"
    },
    "background": {
      "floor": { "value": "<hex floor color>", "source": "measured" | "estimated" | "inferred" | "unknown" },
      "lift": { "value": "<lift/radial glow hex or 'none'>", "source": "measured" | "estimated" | "inferred" | "unknown" },
      "liftFadesAt": { "value": "<position where lift fades e.g. 'top 40%' or 'center'>", "source": "estimated" | "inferred" | "unknown" },
      "grain": { "value": "<'none' | 'subtle-noise' | 'heavy-noise'>", "source": "estimated" | "inferred" | "unknown" },
      "matteGloss": { "value": "<'matte' | 'glossy' | 'satin'>", "source": "estimated" | "inferred" | "unknown" },
      "uniform": <boolean>,
      "noiseLevel": { "value": "<noise level description or value>", "source": "measured" | "estimated" | "unknown" }
    },
    "paletteByRole": [
      {
        "role": "<element role e.g. page-canvas, card-surface, primary-cta, text-primary, text-muted, accent-badge, border>",
        "name": "<descriptive name>",
        "hex": { "value": "<uppercase hex>", "source": "measured" | "estimated" | "inferred" | "unknown" },
        "token": "<CSS custom property token>",
        "usage": "<where and how this color is used>"
      }
    ],
    "copyInventory": [
      {
        "id": "<copy-1, copy-2...>",
        "text": "<EXACT verbatim text casing, punctuation, symbols>",
        "location": "<e.g. top-nav, hero-heading, hero-subheading, cta-button, card-1-title>",
        "caseStyle": "<e.g. Title Case, UPPERCASE, lowercase, sentence case>",
        "source": "measured" | "estimated" | "inferred" | "unknown"
      }
    ],
    "elementInventory": [
      {
        "id": "<el-1, el-2...>",
        "kind": "card" | "button" | "nav" | "text" | "badge" | "icon" | "image" | "character" | "prop" | "input" | "container" | "other",
        "label": "<descriptive label of element>",
        "box": { "ymin": <0-1000>, "xmin": <0-1000>, "ymax": <0-1000>, "xmax": <0-1000> },
        "zOrder": { "value": <integer>, "source": "estimated" | "inferred" },
        "parent": "<parent element id or 'canvas'>",
        "alignment": { "value": "<left | center | right | justify>", "source": "estimated" | "inferred" | "unknown" }
      }
    ],
    "typographyPerElement": [
      {
        "id": "<type-el-1...>",
        "role": "<heading | body | button-label | tag-pill | caption>",
        "sampleText": "<verbatim text from element>",
        "fontCandidates": ["<ranked typeface candidates>"],
        "freeFallback": "<Google/System free font alternative>",
        "size": { "value": "<size in px>", "source": "measured" | "estimated" | "inferred" | "unknown" },
        "weight": { "value": "<numeric weight>", "source": "estimated" | "inferred" | "unknown" },
        "lineHeight": { "value": "<line height ratio or px>", "source": "estimated" | "inferred" | "unknown" },
        "letterSpacing": { "value": "<letter spacing in em/px>", "source": "estimated" | "inferred" | "unknown" },
        "color": { "value": "<hex color>", "source": "measured" | "estimated" | "inferred" | "unknown" }
      }
    ],
    "cardsContainers": [
      {
        "id": "<card-1...>",
        "label": "<card or container name>",
        "radius": { "value": "<radius in px or pill>", "source": "measured" | "estimated" | "inferred" | "unknown" },
        "padding": { "value": "<padding in px>", "source": "estimated" | "inferred" | "unknown" },
        "gradientStops": [
          { "value": "<gradient stop hex color or 'none'>", "source": "measured" | "estimated" | "unknown" }
        ],
        "gloss": { "value": "<'matte' | 'glassmorphic-blur' | 'glossy-reflection' | 'none'>", "source": "estimated" | "inferred" | "unknown" },
        "shadow": { "value": "<box shadow specification>", "source": "estimated" | "inferred" | "unknown" },
        "rotation": { "value": "<rotation degrees e.g. '0deg' or '-4deg'>", "source": "estimated" | "inferred" | "unknown" },
        "overlap": { "value": "<description of overlapping elements or 'none'>", "source": "estimated" | "inferred" | "unknown" },
        "crop": { "value": "<'contained' | 'edge-cropped' | 'overflow-hidden'>", "source": "estimated" | "inferred" | "unknown" }
      }
    ],
    "characters": [
      {
        "id": "<char-1...>",
        "label": "<character/mascot name or label>",
        "description": "<detailed breakdown: who/what it is, clothing, items held, facial expression, pose>",
        "colors": [
          { "value": "<hex color>", "source": "measured" | "estimated" | "unknown" }
        ],
        "materials": { "value": "<e.g. 3D smooth vinyl, clay, flat vector, watercolor>", "source": "estimated" | "inferred" | "unknown" },
        "position": { "value": "<location on page>", "source": "estimated" | "inferred" | "unknown" },
        "box": { "ymin": <0-1000>, "xmin": <0-1000>, "ymax": <0-1000>, "xmax": <0-1000> },
        "crop": { "value": "<'full-figure' | 'cropped-at-waist' | 'headshot'>", "source": "estimated" | "inferred" | "unknown" }
      }
    ],
    "props": [
      {
        "id": "<prop-1...>",
        "label": "<prop name e.g. floating-card-stack, 3d-geometry, cursor-tag>",
        "description": "<physical appearance, geometry, specular highlights, textures>",
        "colors": [
          { "value": "<hex color>", "source": "measured" | "estimated" | "unknown" }
        ],
        "materials": { "value": "<e.g. frosted glass, brushed chrome, matte plastic, paper>", "source": "estimated" | "inferred" | "unknown" },
        "position": { "value": "<location on page>", "source": "estimated" | "inferred" | "unknown" },
        "box": { "ymin": <0-1000>, "xmin": <0-1000>, "ymax": <0-1000>, "xmax": <0-1000> },
        "crop": { "value": "<crop status or 'uncropped'>", "source": "estimated" | "inferred" | "unknown" }
      }
    ],
    "icons": [
      {
        "id": "<icon-1...>",
        "label": "<icon label/role>",
        "name": "<icon identifier e.g. arrow-right, checkmark, search, chevron-down>",
        "description": "<outline, solid fill, duotone, stroke-width>",
        "color": { "value": "<hex color>", "source": "measured" | "estimated" | "inferred" | "unknown" },
        "size": { "value": "<size in px>", "source": "measured" | "estimated" | "inferred" | "unknown" },
        "box": { "ymin": <0-1000>, "xmin": <0-1000>, "ymax": <0-1000>, "xmax": <0-1000> },
        "position": { "value": "<parent element / position>", "source": "estimated" | "inferred" | "unknown" }
      }
    ],
    "shadowsAndShine": [
      {
        "id": "<effect-1...>",
        "target": "<target element or container>",
        "type": "shadow" | "shine" | "glow" | "inset",
        "value": { "value": "<CSS property or highlight formula>", "source": "estimated" | "inferred" | "unknown" },
        "lightDirection": { "value": "<e.g. top-left 45deg, top-down, ambient>", "source": "estimated" | "inferred" | "unknown" }
      }
    ],
    "motion": [
      {
        "element": "<target element>",
        "trigger": "<e.g. on-scroll, hover, loop, entrance>",
        "description": "<physics, easing, transform description>",
        "source": "inferred"
      }
    ],
    "dosAndDonts": {
      "dos": ["<strictly observed visual do rule 1>", "<rule 2>"],
      "donts": ["<strictly observed visual dont rule 1>", "<rule 2>"]
    }
  },
  "dosAndDonts": {
    "dos": ["<do 1>", "<do 2>"],
    "donts": ["<dont 1>", "<dont 2>"]
  }
}`;

export const LOCATE_PROMPT = `You are Loupe's element locator.
Detect all visible distinct UI elements (up to 60 elements) in this interface screenshot.
For each element, specify:
- id: short identifier e.g. "el-1", "el-2"
- kind: one of ["card", "button", "nav", "text", "badge", "icon", "image", "character", "prop", "input", "container", "other"]
- label: descriptive name of the element (e.g. "Hero Heading", "Primary CTA Button", "Avatar Badge")
- box_2d: normalized bounding box [ymin, xmin, ymax, xmax] strictly from 0 to 1000
- text: verbatim visible text inside the element, if applicable

Return ONLY valid JSON:
{
  "elements": [
    {
      "id": string,
      "kind": string,
      "label": string,
      "box_2d": [number, number, number, number],
      "text": string | null
    }
  ]
}`;

export const REGION_PROMPT = `You are Loupe's high-magnification visual inspector.
Examine this zoomed-in crop of a specific UI region and its measured pixel palette.
Extract:
1. Exact verbatim copy text (casing, punctuation, dashes).
2. Per-element typography (exact size, weight, letter spacing, font characteristics).
3. Container shapes, exact corner radii, padding, borders, shadows, and gradient stops.
4. If characters/illustrations or 3D props are present, exhaustively describe what they are, clothing, materials, colors, lighting, and pose.

Return ONLY valid JSON conforming to the regional inspection spec.`;
