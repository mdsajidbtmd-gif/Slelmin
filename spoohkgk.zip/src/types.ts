/**
 * Shared TypeScript types for Loupe v2.0.0
 * Document 2, Section 5.7 & Visual Reproduction Specification
 */

export type ValueSource = 'measured' | 'estimated' | 'inferred' | 'unknown';

export interface SourcedValue<T = string | number> {
  value: T;
  source: ValueSource;
}

export interface Box2D {
  ymin: number; // 0-1000 normalized
  xmin: number; // 0-1000 normalized
  ymax: number; // 0-1000 normalized
  xmax: number; // 0-1000 normalized
}

export interface VisualFrame {
  referenceWidth: number; // default 1440
  coordinateSystem: string;
  conversionRule: string;
  detectedCrop?: {
    x: number;
    y: number;
    width: number;
    height: number;
  };
}

export interface VisualBackground {
  floor: SourcedValue<string>;
  lift?: SourcedValue<string>;
  liftFadesAt?: SourcedValue<string>;
  grain: SourcedValue<string>;
  matteGloss: SourcedValue<string>;
  uniform: boolean;
  noiseLevel: SourcedValue<number | string>;
}

export interface PaletteRoleItem {
  role: string;
  name: string;
  hex: SourcedValue<string>;
  token: string;
  usage: string;
}

export interface CopyItem {
  id: string;
  text: string; // verbatim visible text
  location: string;
  elementId?: string;
  caseStyle?: string;
  source: ValueSource;
}

export interface ElementItem {
  id: string;
  kind:
    | 'card'
    | 'button'
    | 'nav'
    | 'text'
    | 'badge'
    | 'icon'
    | 'image'
    | 'character'
    | 'prop'
    | 'input'
    | 'container'
    | 'other';
  label: string;
  box: Box2D; // 0-1000
  zOrder: SourcedValue<number>;
  parent?: string;
  alignment: SourcedValue<string>;
}

export interface TypographyElement {
  id: string;
  elementId?: string;
  role: string;
  sampleText: string;
  fontCandidates: string[];
  freeFallback: string;
  size: SourcedValue<string>;
  weight: SourcedValue<number | string>;
  lineHeight: SourcedValue<string>;
  letterSpacing: SourcedValue<string>;
  color: SourcedValue<string>;
}

export interface CardContainerSpec {
  id: string;
  label: string;
  elementId?: string;
  box?: Box2D;
  radius: SourcedValue<string>;
  padding: SourcedValue<string>;
  gradientStops: SourcedValue<string>[];
  gloss: SourcedValue<string>;
  shadow: SourcedValue<string>;
  rotation: SourcedValue<string>;
  overlap: SourcedValue<string>;
  crop: SourcedValue<string>;
}

export interface CharacterIllustrationSpec {
  id: string;
  label: string;
  description: string;
  colors: SourcedValue<string>[];
  materials: SourcedValue<string>;
  position: SourcedValue<string>;
  box?: Box2D;
  crop: SourcedValue<string>;
  assetPath?: string;
}

export interface PropSpec {
  id: string;
  label: string;
  description: string;
  colors: SourcedValue<string>[];
  materials: SourcedValue<string>;
  position: SourcedValue<string>;
  box?: Box2D;
  crop: SourcedValue<string>;
  assetPath?: string;
}

export interface IconSpec {
  id: string;
  label: string;
  name: string;
  description: string;
  color: SourcedValue<string>;
  size: SourcedValue<string>;
  box?: Box2D;
  position: SourcedValue<string>;
  assetPath?: string;
}

export interface ShadowShineSpec {
  id: string;
  target: string;
  type: 'shadow' | 'shine' | 'glow' | 'inset';
  value: SourcedValue<string>;
  lightDirection: SourcedValue<string>;
}

export interface MotionSpec {
  element: string;
  trigger: string;
  description: string;
  source: 'inferred';
}

export interface VisualSpec {
  frame: VisualFrame;
  background: VisualBackground;
  paletteByRole: PaletteRoleItem[];
  copyInventory: CopyItem[];
  elementInventory: ElementItem[];
  typographyPerElement: TypographyElement[];
  cardsContainers: CardContainerSpec[];
  characters: CharacterIllustrationSpec[];
  props: PropSpec[];
  icons: IconSpec[];
  shadowsAndShine: ShadowShineSpec[];
  motion: MotionSpec[];
  dosAndDonts: {
    dos: string[];
    donts: string[];
  };
}

export interface ColorToken {
  name: string;
  value: string;
  token: string;
  role: string;
}

export interface TypeScaleItem {
  role: string;
  family: string;
  weight: number | string;
  size: number | string;
  lineHeight: number | string;
  letterSpacing: number | string;
  token: string;
}

export interface TypefaceInfo {
  name: string;
  substitute: string;
  role: string;
  weights: (number | string)[];
  sizes: (number | string)[];
  lineHeight: string;
  letterSpacing: string;
  token: string;
}

export interface SpacingItem {
  name: string;
  value: string;
  token: string;
}

export interface RadiusItem {
  element: string;
  value: string;
  token?: string;
}

export interface ElevationItem {
  name: string;
  value: string;
  token: string;
}

export interface SurfaceItem {
  level: number;
  name: string;
  value: string;
  purpose: string;
}

export interface ComponentSpec {
  name: string;
  role: string;
  description: string;
  props?: Record<string, string>;
  tokensUsed?: string[];
}

export interface DesignSpec {
  meta: {
    title: string;
    theme: 'dark' | 'light' | 'mixed' | string;
    industry: string;
    styleTags: string[];
    sections: string[];
    summary: string;
    description: string;
  };
  colors: ColorToken[];
  typography: {
    primaryFont: TypefaceInfo;
    secondaryFont?: TypefaceInfo;
    utilityFont?: TypefaceInfo;
    typeScale: TypeScaleItem[];
  };
  spacing: {
    baseUnit: number;
    density: string;
    scale: SpacingItem[];
    radii: RadiusItem[];
    shadows: ElevationItem[];
    layout: {
      pageMaxWidth: string;
      sectionGap: string;
      cardPadding: string;
      elementGap: string;
    };
  };
  surfaces: SurfaceItem[];
  components: ComponentSpec[];
  dosAndDonts: {
    dos: string[];
    donts: string[];
  };
  visualSpec?: VisualSpec;
}

export interface ResultImage {
  name: string;
  width: number;
  height: number;
  thumbDataUrl: string;
  dataUrl: string;
  cropRect?: { x: number; y: number; width: number; height: number };
}

export interface Result {
  id: string;
  createdAt: number;
  cacheKey: string;
  title: string;
  tags: {
    industry: string[];
    style: string[];
    sections: string[];
  };
  markdown: string;
  spec: DesignSpec;
  images: ResultImage[];
  shareId?: string;
  assetZipBlob?: any;
}

export interface ShareDoc {
  title: string;
  markdown: string;
  tags: {
    industry: string[];
    style: string[];
    sections: string[];
  };
  imageCount: number;
  coverImage: string;
  deviceId: string;
  createdAt: any;
  copyCount: number;
  visibility: 'unlisted' | 'public';
  publicAt?: any;
  publicCopyCount?: number;
}

export interface ShareImageDoc {
  index: number;
  mime: string;
  width: number;
  height: number;
  dataUrl: string;
}

export interface MeasuredRegion {
  box: Box2D;
  topColor: string;
  middleColor: string;
  bottomColor: string;
  foregroundColor?: string;
}

export interface MeasuredBackground {
  floorColor: string;
  isUniform: boolean;
  edgeSamples: string[];
  cornerSamples: string[];
  centerSample: string;
  topLiftHex?: string;
  topLiftFadePercent?: number;
  sideLiftHex?: string;
  sideLiftFadePercent?: number;
  noiseLevel: number;
}

export interface MeasuredColor {
  hex: string;
  medianRgb?: [number, number, number];
  role?: string;
  percentage?: number;
  chroma?: number;
  score?: number;
  pixelCount?: number;
}

export interface Measurements {
  palette: MeasuredColor[];
  dimensions: { width: number; height: number; aspectRatio: number }[];
  background?: MeasuredBackground;
  regions?: MeasuredRegion[];
  cropRect?: { x: number; y: number; width: number; height: number };
}

export interface SiteGroup {
  id: string;
  label: string;
  description: string;
  sections: string[];
  imageIndices: number[];
}

export interface AnalyzeResult {
  isWebsite: boolean;
  rejectionCode?: string | null;
  rejectionReason?: string | null;
  sites: SiteGroup[];
}

export type StepName = 'check' | 'measure' | 'analyze' | 'extract' | 'validate';

export type PipelineEvent =
  | { type: 'step'; step: StepName; status: 'active' | 'done'; subStep?: string }
  | { type: 'retry'; inSeconds: number; attempt: number }
  | { type: 'cache_hit'; resultId: string }
  | { type: 'rejected'; items: { fileName: string; code: string; reason?: string }[] }
  | { type: 'done'; resultIds: string[] }
  | { type: 'error'; error: Error | { code?: string; message: string } };

export interface PipelineOptions {
  signal: AbortSignal;
  onEvent: (event: PipelineEvent) => void;
  requestChoice: (sites: SiteGroup[]) => Promise<{ siteIds: string[] }>;
}
