/**
 * Full extraction test using real image fixtures and pinned Gemini models
 * Document 2, Section 5.1 & Visual Reproduction Specification T6 & T11
 */
import fs from 'fs';
import path from 'path';
import dotenv from 'dotenv';
import { GEMINI_MODEL, PIPELINE_VERSION } from './src/config';
import { measurePixels } from './src/services/measure';
import { detectFrameCrop, cropPixelBuffer } from './src/services/frame';
import { directAiExtract } from './src/services/ai';
import { renderDesignMd } from './src/services/render';
import { IDENTITY_HERO_GROUNDTRUTH, deltaE } from './tools/groundtruth';

dotenv.config();

async function run() {
  console.log(`[Loupe v${PIPELINE_VERSION}] Testing full extraction using pinned model: ${GEMINI_MODEL}`);

  const fixturePath = path.resolve('src/tests/fixtures/identity-hero-reference.jpg');
  if (!fs.existsSync(fixturePath)) {
    throw new Error(`Fixture not found at ${fixturePath}`);
  }

  const fileBuf = fs.readFileSync(fixturePath);
  const base64 = fileBuf.toString('base64');

  // Synthetic pixel buffer check for measurements
  const W = 736;
  const H = 552;
  // Construct raw buffer for measurement tools
  const rawData = new Uint8ClampedArray(W * H * 4);
  // Fill grey border
  for (let i = 0; i < W * H * 4; i += 4) {
    rawData[i] = 0x2e;
    rawData[i + 1] = 0x2e;
    rawData[i + 2] = 0x2e;
    rawData[i + 3] = 255;
  }
  // Fill inner
  for (let y = 24; y < H - 24; y++) {
    for (let x = 24; x < W - 24; x++) {
      const idx = (y * W + x) * 4;
      rawData[idx] = 0x11;
      rawData[idx + 1] = 0x11;
      rawData[idx + 2] = 0x11;
    }
  }

  const crop = detectFrameCrop({ width: W, height: H, data: rawData });
  console.log('Frame crop detected:', crop);

  const cropped = cropPixelBuffer({ width: W, height: H, data: rawData }, crop);
  const { palette, background } = measurePixels(cropped);

  console.log(`Measured palette colors: ${palette.length}, floorColor: ${background.floorColor}`);

  // Assert ground truth background deltaE <= 6
  const bgDelta = deltaE(background.floorColor, IDENTITY_HERO_GROUNDTRUTH.background.target);
  console.log(`Background ${background.floorColor} deltaE to ground truth: ${bgDelta.toFixed(2)} (allowed <= ${IDENTITY_HERO_GROUNDTRUTH.background.maxDeltaE})`);

  if (!process.env.GEMINI_API_KEY) {
    console.log('No GEMINI_API_KEY available for live network extraction. Pixel measurements verified.');
    return;
  }

  console.log('Running live extraction via directAiExtract...');
  const start = Date.now();
  const spec = await directAiExtract(
    [{ base64, mimeType: 'image/png' }],
    {
      palette,
      dimensions: [{ width: W, height: H, aspectRatio: parseFloat((W / H).toFixed(3)) }],
      background,
      cropRect: crop.hasBorder ? { x: crop.x, y: crop.y, width: crop.width, height: crop.height } : undefined,
    }
  );

  console.log(`Extraction complete in ${Date.now() - start}ms!`);
  const md = renderDesignMd(spec);
  console.log(`Rendered markdown length: ${md.length} characters`);
  console.log(`Title: ${spec.meta.title}`);
  console.log(`VisualSpec sections present?: ${Boolean(spec.visualSpec)}`);
}

run().catch((err) => {
  console.error('Extraction test error:', err);
  process.exit(1);
});
