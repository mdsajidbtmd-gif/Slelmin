/**
 * Ground truth color and tolerance computation for image fixtures
 * Visual Reproduction Specification - T11
 */

export interface BoxCoords {
  ymin: number;
  xmin: number;
  ymax: number;
  xmax: number;
}

export interface PixelData {
  width: number;
  height: number;
  data: Uint8ClampedArray | Uint8Array;
}

export function rgbToHex(r: number, g: number, b: number): string {
  const h = (n: number) => Math.max(0, Math.min(255, Math.round(n))).toString(16).padStart(2, '0').toUpperCase();
  return `#${h(r)}${h(g)}${h(b)}`;
}

export function hexToRgb(hex: string): [number, number, number] {
  const clean = hex.replace('#', '');
  return [
    parseInt(clean.substring(0, 2), 16) || 0,
    parseInt(clean.substring(2, 4), 16) || 0,
    parseInt(clean.substring(4, 6), 16) || 0,
  ];
}

/**
 * Standard DeltaE (CIE76 / Lab Euclidean)
 */
function rgbToLab(r: number, g: number, b: number): [number, number, number] {
  // Convert sRGB to linear RGB
  let lr = r / 255;
  let lg = g / 255;
  let lb = b / 255;

  lr = lr > 0.04045 ? Math.pow((lr + 0.055) / 1.055, 2.4) : lr / 12.92;
  lg = lg > 0.04045 ? Math.pow((lg + 0.055) / 1.055, 2.4) : lg / 12.92;
  lb = lb > 0.04045 ? Math.pow((lb + 0.055) / 1.055, 2.4) : lb / 12.92;

  // Observer = 2°, Illuminant = D65
  let x = lr * 0.4124 + lg * 0.3576 + lb * 0.1805;
  let y = lr * 0.2126 + lg * 0.7152 + lb * 0.0722;
  let z = lr * 0.0193 + lg * 0.1192 + lb * 0.9505;

  x /= 0.95047;
  y /= 1.0;
  z /= 1.08883;

  x = x > 0.008856 ? Math.pow(x, 1 / 3) : 7.787 * x + 16 / 116;
  y = y > 0.008856 ? Math.pow(y, 1 / 3) : 7.787 * y + 16 / 116;
  z = z > 0.008856 ? Math.pow(z, 1 / 3) : 7.787 * z + 16 / 116;

  return [116 * y - 16, 500 * (x - y), 200 * (y - z)];
}

export function deltaE(hex1: string, hex2: string): number {
  const [r1, g1, b1] = hexToRgb(hex1);
  const [r2, g2, b2] = hexToRgb(hex2);

  const [L1, a1, b1_val] = rgbToLab(r1, g1, b1);
  const [L2, a2, b2_val] = rgbToLab(r2, g2, b2);

  return Math.sqrt((L1 - L2) ** 2 + (a1 - a2) ** 2 + (b1_val - b2_val) ** 2);
}

/**
 * Computes median color inside a normalized 0-1000 box
 */
export function computeBoxMedianColor(buffer: PixelData, box: BoxCoords): { hex: string; rgb: [number, number, number] } {
  const { width, height, data } = buffer;

  const ymin = Math.max(0, Math.min(height - 1, Math.round((box.ymin * height) / 1000)));
  const ymax = Math.max(ymin + 1, Math.min(height, Math.round((box.ymax * height) / 1000)));
  const xmin = Math.max(0, Math.min(width - 1, Math.round((box.xmin * width) / 1000)));
  const xmax = Math.max(xmin + 1, Math.min(width, Math.round((box.xmax * width) / 1000)));

  const rList: number[] = [];
  const gList: number[] = [];
  const bList: number[] = [];

  for (let y = ymin; y < ymax; y++) {
    for (let x = xmin; x < xmax; x++) {
      const idx = (y * width + x) * 4;
      if (data[idx + 3] < 128) continue;
      rList.push(data[idx]);
      gList.push(data[idx + 1]);
      bList.push(data[idx + 2]);
    }
  }

  const median = (arr: number[]) => {
    if (arr.length === 0) return 0;
    const sorted = [...arr].sort((a, b) => a - b);
    return sorted[Math.floor(sorted.length / 2)];
  };

  const medR = median(rList);
  const medG = median(gList);
  const medB = median(bList);

  return {
    hex: rgbToHex(medR, medG, medB),
    rgb: [medR, medG, medB],
  };
}

/**
 * Ground truth box definitions and tolerance thresholds for the identity hero reference fixture
 */
export const IDENTITY_HERO_GROUNDTRUTH = {
  background: {
    target: '#111111',
    box: { ymin: 100, xmin: 50, ymax: 200, xmax: 150 },
    maxDeltaE: 6,
  },
  navPill: {
    target: '#242424',
    box: { ymin: 30, xmin: 350, ymax: 70, xmax: 650 },
    maxDeltaE: 6,
  },
  limeCircle: {
    target: '#F2FC4E',
    box: { ymin: 400, xmin: 460, ymax: 480, xmax: 540 },
    maxDeltaE: 10,
  },
  expectedStrings: [
    'Build Your Identity',
    'Connect Your World',
    'Get Started',
    'Robert',
    'Clarissa',
  ],
  expectedCards: ['Cloudy', 'Dummies', 'Glue', 'Groove mumies', 'Ellenor'],
};
