/**
 * Script to generate test fixture images using fflate
 * Creates identity-hero-reference.png, near-empty.png, solid-color.png
 */
import fs from 'fs';
import path from 'path';
import { zlibSync } from 'fflate';

function createPng(width: number, height: number, rgbaData: Uint8Array): Buffer {
  // Build raw scanlines (filter type 0 followed by width * 4 bytes per row)
  const rawScanlines = new Uint8Array(height * (width * 4 + 1));
  for (let y = 0; y < height; y++) {
    const rawOffset = y * (width * 4 + 1);
    rawScanlines[rawOffset] = 0; // Filter None
    const rowData = rgbaData.subarray(y * width * 4, (y + 1) * width * 4);
    rawScanlines.set(rowData, rawOffset + 1);
  }

  const compressed = zlibSync(rawScanlines, { level: 6 });

  // CRC32 helper
  const crcTable = new Uint32Array(256);
  for (let n = 0; n < 256; n++) {
    let c = n;
    for (let k = 0; k < 8; k++) {
      c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
    }
    crcTable[n] = c;
  }

  function crc32(buf: Uint8Array): number {
    let crc = 0xffffffff;
    for (let i = 0; i < buf.length; i++) {
      crc = crcTable[(crc ^ buf[i]) & 0xff] ^ (crc >>> 8);
    }
    return (crc ^ 0xffffffff) >>> 0;
  }

  function writeChunk(type: string, data: Uint8Array): Buffer {
    const len = data.length;
    const buf = Buffer.alloc(12 + len);
    buf.writeUInt32BE(len, 0);
    buf.write(type, 4, 4, 'ascii');
    Buffer.from(data).copy(buf, 8);
    const typeAndData = Buffer.alloc(4 + len);
    typeAndData.write(type, 0, 4, 'ascii');
    Buffer.from(data).copy(typeAndData, 4);
    const crc = crc32(typeAndData);
    buf.writeUInt32BE(crc, 8 + len);
    return buf;
  }

  // IHDR data
  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(width, 0);
  ihdr.writeUInt32BE(height, 4);
  ihdr.writeUInt8(8, 8); // bit depth 8
  ihdr.writeUInt8(6, 9); // RGBA
  ihdr.writeUInt8(0, 10);
  ihdr.writeUInt8(0, 11);
  ihdr.writeUInt8(0, 12);

  const signature = Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]);
  const ihdrChunk = writeChunk('IHDR', ihdr);
  const idatChunk = writeChunk('IDAT', compressed);
  const iendChunk = writeChunk('IEND', new Uint8Array(0));

  return Buffer.concat([signature, ihdrChunk, idatChunk, iendChunk]);
}

// ----------------------------------------------------------------------------
// Generator
// ----------------------------------------------------------------------------
const dir = path.resolve('src/tests/fixtures');
if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });

const W = 736;
const H = 552;

// 1. Identity Hero Reference
const idData = new Uint8Array(W * H * 4);

function fillRect(x1: number, y1: number, x2: number, y2: number, r: number, g: number, b: number) {
  for (let y = Math.max(0, y1); y < Math.min(H, y2); y++) {
    for (let x = Math.max(0, x1); x < Math.min(W, x2); x++) {
      const idx = (y * W + x) * 4;
      idData[idx] = r;
      idData[idx + 1] = g;
      idData[idx + 2] = b;
      idData[idx + 3] = 255;
    }
  }
}

// Outer grey presentation mat #2E2E2E
fillRect(0, 0, W, H, 0x2e, 0x2e, 0x2e);

// Inner main design canvas #111111 (24px padding around)
fillRect(24, 24, W - 24, H - 24, 0x11, 0x11, 0x11);

// Nav Pill #242424 with border
fillRect(240, 40, 496, 75, 0x24, 0x24, 0x24);

// Lime circle #F2FC4E
const cx = 368, cy = 250, radius = 45;
for (let y = cy - radius; y <= cy + radius; y++) {
  for (let x = cx - radius; x <= cx + radius; x++) {
    if ((x - cx) ** 2 + (y - cy) ** 2 <= radius ** 2) {
      const idx = (y * W + x) * 4;
      idData[idx] = 0xf2;
      idData[idx + 1] = 0xfc;
      idData[idx + 2] = 0x4e;
      idData[idx + 3] = 255;
    }
  }
}

// Cards: Cloudy, Dummies, Glue, Groove mumies, Ellenor
const cardY = 360;
fillRect(60, cardY, 170, cardY + 120, 0x1c, 0x1c, 0x1c); // Cloudy
fillRect(190, cardY, 300, cardY + 120, 0x1e, 0x1e, 0x1e); // Dummies
fillRect(320, cardY, 430, cardY + 120, 0x22, 0x22, 0x22); // Glue
fillRect(450, cardY, 560, cardY + 120, 0x1d, 0x1d, 0x1d); // Groove mumies
fillRect(580, cardY, 680, cardY + 120, 0x20, 0x20, 0x20); // Ellenor

// Cursor tags: Robert, Clarissa
fillRect(140, 200, 210, 225, 0x4f, 0x46, 0xe5); // Robert
fillRect(520, 210, 590, 235, 0xec, 0x48, 0x99); // Clarissa

// 2 prop groups
fillRect(70, 100, 130, 160, 0x3b, 0x82, 0xf6);
fillRect(600, 110, 660, 170, 0x10, 0xb9, 0x81);

const idBuf = createPng(W, H, idData);
fs.writeFileSync(path.join(dir, 'identity-hero-reference.jpg'), idBuf);
fs.writeFileSync(path.join(dir, 'identity-hero-reference.png'), idBuf);

// 2. Near-empty fixture
const emptyData = new Uint8Array(W * H * 4);
for (let i = 0; i < W * H * 4; i += 4) {
  emptyData[i] = 15;
  emptyData[i + 1] = 15;
  emptyData[i + 2] = 15;
  emptyData[i + 3] = 255;
}
const emptyBuf = createPng(W, H, emptyData);
fs.writeFileSync(path.join(dir, 'near-empty.jpg'), emptyBuf);

// 3. Solid-color fixture
const solidData = new Uint8Array(W * H * 4);
for (let i = 0; i < W * H * 4; i += 4) {
  solidData[i] = 31;
  solidData[i + 1] = 41;
  solidData[i + 2] = 55;
  solidData[i + 3] = 255;
}
const solidBuf = createPng(W, H, solidData);
fs.writeFileSync(path.join(dir, 'solid-color.jpg'), solidBuf);

console.log('Fixtures generated successfully in src/tests/fixtures');
